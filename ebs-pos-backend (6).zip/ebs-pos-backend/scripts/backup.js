// Safe online backup of the SQLite database + uploaded files.  Usage: node scripts/backup.js [target-folder]
const fs = require('fs'), path = require('path');
const cfg = require('../src/config'); const { db } = require('../src/db');
const dir = path.resolve(process.argv[2] || path.join(cfg.dataDir, 'backups'));
const stamp = new Date().toISOString().replace(/[:T]/g, '-').slice(0, 19);
fs.mkdirSync(dir, { recursive: true });
db.backup(path.join(dir, `ebs-${stamp}.sqlite`)).then(() => {
  const up = path.join(cfg.dataDir, 'uploads'), dst = path.join(dir, `uploads-${stamp}`);
  if (fs.existsSync(up)) fs.cpSync(up, dst, { recursive: true });
  // keep the newest 30 database backups
  fs.readdirSync(dir).filter(f => /^ebs-.*\.sqlite$/.test(f)).sort().reverse().slice(30).forEach(f => fs.rmSync(path.join(dir, f)));
  console.log('Backup written to ' + dir + ' (' + stamp + ')'); process.exit(0);
}).catch(e => { console.error('Backup failed:', e.message); process.exit(1); });
