// Builds public/index.html from the demo front-end file for production use:
//  * removes every demo account (and its password) and all sample records from the page source
//  * so nothing sensitive or fake is ever sent to a visitor's browser.
// Usage: node scripts/build-frontend.js path/to/demo.html   (default: ./frontend-demo.html)
const fs = require('fs'), path = require('path');
const src = path.resolve(process.argv[2] || path.join(__dirname, '..', 'frontend-demo.html'));
let html = fs.readFileSync(src, 'utf8');

const SEEDS = [ // variable name + the start of its initial value
  ['P1', '[{id:"u1",username:"admin1"'], ['R1', '[Zt("POS-1001"'], ['ty', '[he("356938035643001"'],
  ['ey', '[Bu("356938035643001"'], ['ly', '[{id:"ra-1"'], ['uy', '[{id:"fm-1"'], ['oy', '[{id:"rp-1"'],
];
function matchEnd(s, start) { // index just after the "]" that closes the "[" at `start`
  let depth = 0, q = null;
  for (let i = start; i < s.length; i++) {
    const c = s[i];
    if (q) { if (c === '\\') i++; else if (c === q) q = null; continue; }
    if (c === '"' || c === "'" || c === '`') { q = c; continue; }
    if (c === '[') depth++; else if (c === ']' && --depth === 0) return i + 1;
  }
  throw new Error('unbalanced');
}
let removed = 0;
for (const [name, start] of SEEDS) {
  const key = name + '=' + start, at = html.indexOf(key);
  if (at < 0) { console.warn('  (not found, skipped) ' + name); continue; }
  const open = at + name.length + 1, end = matchEnd(html, open);
  html = html.slice(0, open) + '[]' + html.slice(end); removed++;
}
html = html.replace('var Oc="Welcome@2026"', 'var Oc=""');
// final safety net
const leaks = ['Password@123!', 'ITSup@2026', 'Viewer@2026', 'Logistics@2026', 'Hoc@2026', 'Commercial@2026', 'Supervisor@2026', 'Welcome@2026'].filter(p => html.includes(p));
if (leaks.length) { console.error('Build refused — demo passwords still present: ' + leaks.join(', ')); process.exit(1); }
const out = path.join(__dirname, '..', 'public', 'index.html');
fs.mkdirSync(path.dirname(out), { recursive: true });
fs.writeFileSync(out, html);
console.log(`Built ${out} (${(html.length / 1024).toFixed(0)} KB, ${removed} demo data sets removed)`);
