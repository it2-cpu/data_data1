// Emergency: set a new password for a user and unlock the account.  Usage: node scripts/reset-admin.js <username> <new-password>
const { db, audit } = require('../src/db'); const auth = require('../src/auth');
const [u, pw] = process.argv.slice(2);
if (!u || !pw) { console.error('Usage: node scripts/reset-admin.js <username> <new-password>'); process.exit(1); }
const p = auth.passwordProblem(pw); if (p) { console.error(p); process.exit(1); }
const r = db.prepare('UPDATE users SET password_hash=?, must_change_password=1, failed_attempts=0, locked=0, status=\'Active\' WHERE username=?').run(auth.hash(pw), u.toLowerCase());
if (!r.changes) { console.error('No such user.'); process.exit(1); }
db.prepare('DELETE FROM sessions WHERE user_id IN (SELECT id FROM users WHERE username=?)').run(u.toLowerCase());
audit('system', `Password reset from the server console for ${u}`); console.log('Done. The user must change this password at next login.');
