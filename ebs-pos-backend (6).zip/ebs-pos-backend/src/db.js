const fs = require('fs');
const path = require('path');
const Database = require('better-sqlite3');
const cfg = require('./config');
const { C } = require('./collections');

fs.mkdirSync(cfg.dataDir, { recursive: true });
fs.mkdirSync(path.join(cfg.dataDir, 'uploads'), { recursive: true });
const db = new Database(process.env.DB_FILE || path.join(cfg.dataDir, 'ebs.sqlite'));
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');
db.pragma('busy_timeout = 5000');

db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id TEXT PRIMARY KEY,
  username TEXT NOT NULL UNIQUE COLLATE NOCASE,
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL,
  full_name TEXT NOT NULL,
  email TEXT DEFAULT '',
  status TEXT NOT NULL DEFAULT 'Active',
  zones TEXT,
  must_change_password INTEGER NOT NULL DEFAULT 0,
  failed_attempts INTEGER NOT NULL DEFAULT 0,
  locked INTEGER NOT NULL DEFAULT 0,
  last_login TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS sessions (
  token_hash TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  csrf TEXT NOT NULL,
  created_at INTEGER NOT NULL,
  last_seen INTEGER NOT NULL,
  ip TEXT, user_agent TEXT
);
CREATE INDEX IF NOT EXISTS ix_sessions_user ON sessions(user_id);
CREATE TABLE IF NOT EXISTS audit_log (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  time TEXT NOT NULL,
  user TEXT NOT NULL,
  action TEXT NOT NULL,
  collection TEXT, record_id TEXT, ip TEXT
);
CREATE INDEX IF NOT EXISTS ix_audit_time ON audit_log(time);
CREATE TABLE IF NOT EXISTS messages (
  id TEXT PRIMARY KEY,
  record_id TEXT,
  kind TEXT,
  msg TEXT NOT NULL,
  roles TEXT NOT NULL,
  seen_by TEXT NOT NULL DEFAULT '[]',
  created_by TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE INDEX IF NOT EXISTS ix_messages_record ON messages(record_id);
CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL, updated_by TEXT, updated_at TEXT);
CREATE TABLE IF NOT EXISTS files (
  id TEXT PRIMARY KEY, mime TEXT NOT NULL, size INTEGER NOT NULL, path TEXT NOT NULL,
  uploaded_by TEXT, created_at TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS custom_fields (
  id TEXT PRIMARY KEY, scope TEXT NOT NULL, data TEXT NOT NULL,
  created_by TEXT, created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_by TEXT, updated_at TEXT, version INTEGER NOT NULL DEFAULT 1
);
`);

const seen = new Set();
for (const [name, c] of Object.entries(C)) {
  if (c.customField || seen.has(c.table)) continue;
  seen.add(c.table);
  db.exec(`
CREATE TABLE IF NOT EXISTS ${c.table} (
  id TEXT PRIMARY KEY,
  pos TEXT, imei TEXT, serial TEXT, zone TEXT, status TEXT, rec_date TEXT,
  data TEXT NOT NULL,
  created_by TEXT, created_at TEXT NOT NULL DEFAULT (datetime('now')),
  updated_by TEXT, updated_at TEXT, version INTEGER NOT NULL DEFAULT 1
);
CREATE INDEX IF NOT EXISTS ix_${c.table}_pos ON ${c.table}(pos);
CREATE INDEX IF NOT EXISTS ix_${c.table}_imei ON ${c.table}(imei);
CREATE INDEX IF NOT EXISTS ix_${c.table}_zone ON ${c.table}(zone);`);
}

const nowStamp = () => new Date().toISOString().slice(0, 16).replace('T', ' ');
function audit(user, action, extra = {}) {
  db.prepare('INSERT INTO audit_log(time,user,action,collection,record_id,ip) VALUES (?,?,?,?,?,?)')
    .run(nowStamp(), user || 'system', action, extra.collection || null, extra.recordId || null, extra.ip || null);
}
module.exports = { db, audit, nowStamp };
