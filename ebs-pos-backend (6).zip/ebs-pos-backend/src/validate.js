// Server-side business rules. Throw Rejection(message) to refuse a change.
class Rejection extends Error {}
const fail = m => { throw new Rejection(m); };
const has = v => v !== undefined && v !== null && String(v).trim() !== '';
const changed = (prev, next, k) => !prev ? has(next[k]) : String(prev[k] ?? '') !== String(next[k] ?? '');

const IMEI_COLS = ['deployments', 'maintenances', 'retrievals', 'faulty', 'replacements', 'fieldDeployments'];
const SIM_COLS = { deployments: 'sim', retailers: 'sim', fieldDeployments: 'sim' };
const { db } = require('./db');
const APPROVAL_COLS = ['retailers', 'stockDelivery', 'spareReceipts', 'logistics'];
const isHC = u => u.role === 'HOC' || u.role === 'Commercial';

function validateRecord(collection, { user, prev, next }) {
  // --- format rules (only enforced when the value is new or changed, so old data can still be edited)
  if (IMEI_COLS.includes(collection) && has(next.imei) && changed(prev, next, 'imei') && !/^\d{15}$/.test(String(next.imei)))
    fail('Machine IMEI must be exactly 15 digits (no more, no less).');
  const simKey = SIM_COLS[collection];
  if (simKey && has(next[simKey]) && changed(prev, next, simKey) && !/^\+232 \d{8}$/.test(String(next[simKey])))
    fail('SIM number must be +232 followed by exactly 8 digits.');

  if (collection === 'simRegister') {
    if (!/^\+232 \d{8}$/.test(String(next.sim || ''))) fail('SIM number must be +232 followed by exactly 8 digits.');
    const dup = db.prepare("SELECT id FROM sim_register WHERE json_extract(data,'$.sim') = ? AND id <> ?").get(next.sim, next.id);
    if (dup) fail(next.sim + ' is already in the SIM register.');
  }

  // --- required fields on creation
  if (!prev) {
    if (collection === 'deployments') for (const [k, l] of [['pos', 'POS Number'], ['imei', 'Machine IMEI'], ['serial', 'Serial Number'], ['date', 'Date of Deployment'], ['sim', 'SIM Number'], ['zone', 'Zone'], ['kiosk', 'Kiosk']])
      if (!has(next[k])) fail(`${l} is required.`);
    if (collection === 'fieldDeployments') {
      if (!has(next.pos)) fail('POS Number is required.');
      if (!has(next.shipDate)) fail('Date of Shipment is required.');
      if (!has(next.quantity) || !/^\d+$/.test(String(next.quantity))) fail('Quantity must be a whole number.');
    }
  }

  // --- approval workflow (Pending -> Supervisor Approved -> Validated)
  if (APPROVAL_COLS.includes(collection) && changed(prev, next, 'validationStatus') && has(next.validationStatus)) {
    const s = next.validationStatus, r = user.role;
    if (!['Pending', 'Supervisor Approved', 'Validated'].includes(s)) fail('Unknown approval status.');
    if (!prev && isHC(user) && s !== 'Pending') fail('New applications from HOC / Commercial must start as Pending.');
    if (s === 'Supervisor Approved' && !['Supervisor', 'Admin'].includes(r)) fail('Only a Supervisor can approve this record.');
    if (s === 'Validated' && !['IT Supervisor', 'Admin'].includes(r) && !(collection === 'retailers' && !prev && !isHC(user))) fail('Only the IT Supervisor can confirm this record.');
    if (s === 'Validated' && prev && prev.validationStatus === 'Pending' && r !== 'Admin' && collection !== 'retailers' && collection !== 'logistics') fail('A Supervisor must approve this record before IT can confirm it.');
    if (prev && prev.validationStatus === 'Validated' && s !== 'Validated' && r !== 'Admin') fail('A confirmed record cannot be reopened.');
  }
  if (collection === 'retailers' && prev && isHC(user)) fail('HOC / Commercial users can submit applications but cannot edit them afterwards.');
  if (collection === 'retailers' && isHC(user) && !prev) {
    const z = next.zone; if (has(z) && Array.isArray(user.zones) && !user.zones.includes(z)) fail('That zone is not assigned to your account.');
  }
  if (collection === 'retailers' && changed(prev, next, 'sim') && has(next.sim) && !['Admin', 'IT Supervisor'].includes(user.role)) fail('Only IT can enter the Device SIM Number.');

  if (collection === 'fieldDeployments') fieldDeployment(user, prev, next);
}

function fieldDeployment(user, prev, next) {
  const r = user.role, admin = r === 'Admin';
  if (prev && prev.shipConfirmedBy && prev.receptionConfirmedBy && prev.deployConfirmedBy) fail('This record is locked — shipment, reception and deployment are all confirmed.');
  const can = (k, roles) => { if (changed(prev, next, k) && !roles.includes(r)) fail(`Your role cannot change "${k}" on a shipment record.`); };
  can('shipDate', ['Logistic', 'Admin']);
  can('receivedDate', ['HOC', 'Commercial', 'Admin']);
  can('deployDate', ['HOC', 'Commercial', 'Logistic', 'Admin']);
  if (changed(prev, next, 'pos') && prev && !admin && !['IT Supervisor', 'Logistic'].includes(r)) fail('You cannot change the POS Number.');
  if (!prev && !['Logistic', 'Admin', 'IT Supervisor'].includes(r)) fail('Only Logistic can create a shipment.');
  const conf = [
    ['shipConfirmedBy', 'shipConfirmedAt', ['Supervisor', 'IT Supervisor', 'Admin'], 'shipDate'],
    ['receptionConfirmedBy', 'receptionConfirmedAt', ['HOC', 'Commercial', 'Admin'], 'receivedDate'],
    ['deployConfirmedBy', 'deployConfirmedAt', ['HOC', 'Commercial', 'Admin'], 'deployDate'],
  ];
  for (const [by, at, roles, dateKey] of conf) {
    if (prev && prev[by] && String(next[by] || '') !== String(prev[by])) fail('A confirmation cannot be removed or changed.');
    if (changed(prev, next, by) && has(next[by])) {
      if (!roles.includes(r)) fail('Your role cannot make this confirmation.');
      if (next[by] !== user.username) fail('A confirmation must be made under your own username.');
      if (!has(next[dateKey])) fail('The date must be filled in before it can be confirmed.');
    }
  }
}

module.exports = { validateRecord, Rejection, has, isHC };
