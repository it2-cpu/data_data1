// Every record type the app stores. Each gets its own SQLite table with
// indexed lookup columns plus a JSON "data" column for the remaining fields,
// so screens/fields can change without a schema migration.
const ALL = ['Admin', 'IT Supervisor', 'Supervisor', 'Viewer', 'Logistic', 'HOC', 'Commercial'];

const C = {
  retailers:        { table: 'retailer_applications', label: 'Retailer application', write: ['Admin', 'IT Supervisor', 'HOC', 'Commercial'], del: ['Admin'], read: ALL },
  deployments:      { table: 'deployments',           label: 'Deployment record',    write: ['Admin', 'IT Supervisor'], del: ['Admin'], read: ALL },
  maintenances:     { table: 'maintenance',           label: 'Maintenance record',   write: ['Admin', 'IT Supervisor'], del: ['Admin'], read: ALL },
  retrievals:       { table: 'retrievals',            label: 'Retrieval',            write: ['Admin', 'IT Supervisor'], del: ['Admin'], read: ALL },
  faulty:           { table: 'faulty_machines',       label: 'Faulty machine',       write: ['Admin', 'IT Supervisor'], del: ['Admin'], read: ALL },
  replacements:     { table: 'replacements',          label: 'Replacement',          write: ['Admin', 'IT Supervisor'], del: ['Admin'], read: ALL },
  simRegister:      { table: 'sim_register',          label: 'SIM number',           write: ['Admin', 'IT Supervisor'], del: ['Admin'], read: ALL },
  fieldDeployments: { table: 'field_deployments',     label: 'Shipment / field deployment', write: ['Admin', 'IT Supervisor', 'Logistic', 'HOC', 'Commercial', 'Supervisor'], del: [], read: ALL },
  logistics:        { table: 'logistics',             label: 'Logistics record',     write: ['Admin', 'IT Supervisor', 'Logistic', 'Supervisor'], del: ['Admin'], read: ALL },
  stockDelivery:    { table: 'stock_deliveries',      label: 'Stock delivery',       write: ['Admin', 'IT Supervisor', 'Logistic', 'Supervisor'], del: ['Admin'], read: ALL },
  spareReceipts:    { table: 'spare_part_receipts',   label: 'Spare part receipt',   write: ['Admin', 'IT Supervisor', 'Logistic', 'Supervisor'], del: ['Admin'], read: ALL },
};
// Custom-field definitions (Admin-managed columns added from the UI)
for (const k of ['deployment', 'maintenance', 'retrieval', 'faulty', 'retailer', 'replacement', 'logistics', 'fielddeployment']) {
  C['cf_' + k] = { table: 'custom_fields', label: 'Custom field', write: ['Admin', 'IT Supervisor'], del: ['Admin', 'IT Supervisor'], read: ALL, customField: k };
}
// Settings (single values)
const SETTINGS = { stockBalance: { write: ['Admin', 'IT Supervisor', 'Logistic', 'Supervisor'] }, spareParts: { write: ['Admin', 'IT Supervisor', 'Logistic', 'Supervisor'] } };

module.exports = { C, ALL, SETTINGS, ROLES: ALL };
