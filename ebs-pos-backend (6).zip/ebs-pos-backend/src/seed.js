const crypto = require('crypto');
const { db, audit } = require('./db');
const cfg = require('./config');
const auth = require('./auth');

const DEMO = [
  ['u1', 'admin1', 'Password@123!', 'Admin', 'Julien Munnia', 'julien.munnia@elephantbet.sl'],
  ['u2', 'itsupervisor', 'ITSup@2026', 'IT Supervisor', 'Mohamed Sesay', 'mohamed.sesay@elephantbet.sl'],
  ['u3', 'viewer', 'Viewer@2026', 'Viewer', 'Fatmata Conteh', 'fatmata.conteh@elephantbet.sl'],
  ['u4', 'logistics', 'Logistics@2026', 'Logistic', 'Ibrahim Kamara', 'ibrahim.kamara@elephantbet.sl'],
  ['u5', 'hoc', 'Hoc@2026', 'HOC', 'Sallieu Bangura', 'sallieu.bangura@elephantbet.sl', ['Freetown', 'Western 01']],
  ['u6', 'commercial', 'Commercial@2026', 'Commercial', 'Isata Turay', 'isata.turay@elephantbet.sl', ['Northern 02']],
  ['u7', 'supervisor', 'Supervisor@2026', 'Supervisor', 'Abu Bakarr Jalloh', 'abubakarr.jalloh@elephantbet.sl'],
  ['u8', 'fgbetu', 'SuperAdmin@2026', 'Admin', 'Frederick T. Gbetu', 'frederick.gbetu@elephantbet.sl'],
  ['u9', 'mtborbor', 'SuperAdmin2@2026', 'Admin', 'Michael T. Borbor', 'michael.borbor@elephantbet.sl'],
];
function ensureSeed() {
  if (db.prepare('SELECT COUNT(*) c FROM users').get().c > 0) return;
  const insert = db.prepare('INSERT INTO users(id,username,password_hash,role,full_name,email,status,zones,must_change_password) VALUES (?,?,?,?,?,?,?,?,?)');
  if (cfg.seedDemoUsers) {
    for (const [id, u, p, role, name, email, zones] of DEMO) insert.run(id, u, auth.hash(p), role, name, email, 'Active', zones ? JSON.stringify(zones) : null, 0);
    console.log('Seeded 8 DEMO accounts (SEED_DEMO_USERS=1). Do not use this setting in production.');
  } else {
    const pw = cfg.adminInitialPassword || crypto.randomBytes(9).toString('base64url');
    insert.run('u1', 'admin1', auth.hash(pw), 'Admin', 'System Administrator', '', 'Active', null, 1);
    console.log('\n==============================================================');
    console.log(' First run: created Admin account  admin1');
    if (!cfg.adminInitialPassword) console.log(' Temporary password (shown once):  ' + pw);
    console.log(' You will be asked to change it at first login.');
    console.log('==============================================================\n');
  }
  audit('system', 'Database initialised');
}
module.exports = { ensureSeed };
if (require.main === module) ensureSeed();
