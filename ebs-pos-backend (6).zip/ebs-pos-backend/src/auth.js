const crypto = require('crypto');
const bcrypt = require('bcryptjs');
const cfg = require('./config');
const { db, audit } = require('./db');

const sha = s => crypto.createHash('sha256').update(s).digest('hex');
const publicUser = u => ({
  id: u.id, username: u.username, role: u.role, fullName: u.full_name, email: u.email || '', status: u.status,
  zones: u.zones ? JSON.parse(u.zones) : undefined, mustChangePassword: !!u.must_change_password,
  lastLogin: u.last_login || 'Never', locked: !!u.locked,
});
// constant-ish time even for unknown users
const DUMMY = bcrypt.hashSync('not-a-real-password', 10);

function login(username, password, req) {
  const name = String(username || '').trim().toLowerCase();
  const u = db.prepare('SELECT * FROM users WHERE username = ?').get(name);
  const ip = req.ip;
  if (u && u.locked) { audit(name, 'Login refused — account locked', { ip }); return { error: 'This account is locked after 5 failed attempts. Contact your Admin to reset it.', code: 423 }; }
  const ok = bcrypt.compareSync(String(password || ''), u ? u.password_hash : DUMMY) && !!u;
  if (!ok) {
    if (u) {
      const n = u.failed_attempts + 1, lock = n >= cfg.maxFailed ? 1 : 0;
      db.prepare('UPDATE users SET failed_attempts=?, locked=? WHERE id=?').run(n, lock, u.id);
      audit(name, lock ? 'Account locked after 5 failed logins' : 'Failed login', { ip });
      const left = cfg.maxFailed - n;
      return { error: left > 0 ? `Incorrect username or password. ${left} attempt(s) remaining before lockout.` : 'Account locked after 5 failed attempts.', code: 401 };
    }
    return { error: 'Incorrect username or password.', code: 401 };
  }
  if (u.status !== 'Active') { audit(name, 'Login refused — account suspended', { ip }); return { error: 'This account is suspended. Contact your Admin.', code: 403 }; }
  const token = crypto.randomBytes(32).toString('hex'), csrf = crypto.randomBytes(24).toString('hex'), now = Date.now();
  db.prepare('UPDATE users SET failed_attempts=0, last_login=? WHERE id=?').run(new Date().toISOString().slice(0, 16).replace('T', ' '), u.id);
  db.prepare('INSERT INTO sessions(token_hash,user_id,csrf,created_at,last_seen,ip,user_agent) VALUES (?,?,?,?,?,?,?)')
    .run(sha(token), u.id, csrf, now, now, ip, String(req.get('user-agent') || '').slice(0, 200));
  audit(u.username, 'Logged in', { ip });
  return { token, csrf, user: publicUser(db.prepare('SELECT * FROM users WHERE id=?').get(u.id)) };
}

function sessionFrom(token) {
  if (!token) return null;
  const s = db.prepare('SELECT * FROM sessions WHERE token_hash = ?').get(sha(token));
  if (!s) return null;
  const now = Date.now();
  if (now - s.last_seen > cfg.idleMs) { db.prepare('DELETE FROM sessions WHERE token_hash=?').run(s.token_hash); return { expired: true, userId: s.user_id }; }
  const u = db.prepare('SELECT * FROM users WHERE id = ?').get(s.user_id);
  if (!u || u.status !== 'Active' || u.locked) { db.prepare('DELETE FROM sessions WHERE token_hash=?').run(s.token_hash); return null; }
  db.prepare('UPDATE sessions SET last_seen=? WHERE token_hash=?').run(now, s.token_hash);
  return { csrf: s.csrf, hash: s.token_hash, user: { ...publicUser(u) } };
}
const destroy = token => token && db.prepare('DELETE FROM sessions WHERE token_hash=?').run(sha(token));
const destroyAllFor = userId => db.prepare('DELETE FROM sessions WHERE user_id=?').run(userId);
const purgeExpired = () => db.prepare('DELETE FROM sessions WHERE last_seen < ?').run(Date.now() - cfg.idleMs);

const hash = pw => bcrypt.hashSync(pw, 11);
const verify = (pw, h) => bcrypt.compareSync(pw, h);
function passwordProblem(pw) {
  if (typeof pw !== 'string' || pw.length < 8) return 'Password must be at least 8 characters.';
  if (pw.length > 200) return 'Password is too long.';
  return null;
}
module.exports = { login, sessionFrom, destroy, destroyAllFor, purgeExpired, hash, verify, passwordProblem, publicUser };
