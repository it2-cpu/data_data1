const path = require('path');
try { require('fs').readFileSync(path.join(__dirname, '..', '.env'), 'utf8').split(/\r?\n/).forEach(l => {
  const m = l.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*?)\s*$/); if (m && !l.trim().startsWith('#') && process.env[m[1]] === undefined) process.env[m[1]] = m[2];
}); } catch (_) {}
const root = path.join(__dirname, '..');
module.exports = {
  port: Number(process.env.PORT || 3000),
  prod: process.env.NODE_ENV === 'production',
  dataDir: path.resolve(root, process.env.DATA_DIR || './data'),
  cookieSecure: process.env.COOKIE_SECURE === '1',
  idleMs: Number(process.env.SESSION_IDLE_MINUTES || 15) * 60 * 1000,
  maxFailed: 5,
  // Super Admins: Admin accounts that plain Admins cannot see, edit, reset or read the audit entries of.
  superAdmins: (process.env.SUPER_ADMINS || 'fgbetu,mtborbor').split(',').map(x => x.trim().toLowerCase()).filter(Boolean),
  adminInitialPassword: process.env.ADMIN_INITIAL_PASSWORD || '',
  seedDemoUsers: process.env.SEED_DEMO_USERS === '1',
  corsOrigin: process.env.CORS_ORIGIN || '',
  publicDir: path.join(root, 'public'),
};
