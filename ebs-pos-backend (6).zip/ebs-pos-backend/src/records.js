const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const cfg = require('./config');
const { db, audit, nowStamp } = require('./db');
const { C, SETTINGS } = require('./collections');
const { validateRecord, Rejection, has } = require('./validate');

const MIME_EXT = { 'image/png': 'png', 'image/jpeg': 'jpg', 'image/webp': 'webp', 'image/gif': 'gif', 'application/pdf': 'pdf' };
const MAX_FILE = 5 * 1024 * 1024;

// Replace embedded base64 uploads (photos / PDFs) with authenticated file URLs.
function extractFiles(obj, user, depth = 0) {
  if (depth > 6 || obj === null || typeof obj !== 'object') return obj;
  for (const k of Object.keys(obj)) {
    const v = obj[k];
    if (typeof v === 'string' && v.startsWith('data:')) {
      const m = v.match(/^data:([a-z]+\/[a-z0-9.+-]+);base64,([A-Za-z0-9+/=\s]+)$/i);
      if (!m || !MIME_EXT[m[1].toLowerCase()]) throw new Rejection('Unsupported file type. Allowed: PNG, JPG, WEBP, GIF, PDF.');
      const buf = Buffer.from(m[2], 'base64');
      if (buf.length > MAX_FILE) throw new Rejection('File is larger than 5 MB.');
      const id = crypto.randomBytes(16).toString('hex'), mime = m[1].toLowerCase();
      const rel = id + '.' + MIME_EXT[mime];
      fs.writeFileSync(path.join(cfg.dataDir, 'uploads', rel), buf);
      db.prepare('INSERT INTO files(id,mime,size,path,uploaded_by) VALUES (?,?,?,?,?)').run(id, mime, buf.length, rel, user.username);
      obj[k] = '/api/files/' + id;
    } else if (v && typeof v === 'object') extractFiles(v, user, depth + 1);
  }
  return obj;
}

const sel = {}, ins = {}, upd = {}, del = {};
function stmts(table) {
  if (sel[table]) return;
  sel[table] = db.prepare(`SELECT * FROM ${table} WHERE id = ?`);
  ins[table] = db.prepare(`INSERT INTO ${table}(id,pos,imei,serial,zone,status,rec_date,data,created_by,updated_by,updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?)`);
  upd[table] = db.prepare(`UPDATE ${table} SET pos=?,imei=?,serial=?,zone=?,status=?,rec_date=?,data=?,updated_by=?,updated_at=?,version=version+1 WHERE id=?`);
  del[table] = db.prepare(`DELETE FROM ${table} WHERE id = ?`);
}
const cols = o => [o.pos, o.imei, o.serial, o.zone, o.validationStatus || o.status || null, o.date || o.shipDate || o.deliveryDate || null].map(v => (v == null ? null : String(v)));
const same = (a, b) => JSON.stringify(a) === JSON.stringify(b);
const parse = r => JSON.parse(r.data);

function can(list, user) { return list.includes(user.role); }

function readCollection(name, user) {
  const c = C[name];
  if (c.customField) return db.prepare('SELECT data FROM custom_fields WHERE scope=? ORDER BY rowid').all(c.customField).map(parse);
  stmts(c.table);
  let rows = db.prepare(`SELECT data FROM ${c.table} ORDER BY rowid DESC`).all().map(parse);
  // HOC / Commercial only see retailer applications in their own zones
  if (name === 'retailers' && (user.role === 'HOC' || user.role === 'Commercial') && Array.isArray(user.zones))
    rows = rows.filter(r => !r.zone || user.zones.includes(r.zone));
  return rows;
}

function applyChange(name, change, user, ip) {
  const c = C[name], results = [];
  if (!c) return [{ ok: false, error: 'Unknown collection.' }];
  if (!can(c.read, user)) return [{ ok: false, error: 'No access.' }];
  const isCF = !!c.customField;
  if (!isCF) stmts(c.table);
  const one = (id, fn) => {
    db.exec('SAVEPOINT rec');
    try { fn(); db.exec('RELEASE rec'); results.push({ id, ok: true }); }
    catch (e) {
      db.exec('ROLLBACK TO rec'); db.exec('RELEASE rec');
      if (e instanceof Rejection) results.push({ id, ok: false, error: e.message });
      else { console.error(e); results.push({ id, ok: false, error: 'Server error.' }); }
    }
  };
  for (const rec of change.upsert || []) {
    const id = rec && typeof rec.id === 'string' ? rec.id : '';
    one(id, () => {
      if (!id || id.length > 120) throw new Rejection('Record has no valid id.');
      if (!can(c.write, user)) throw new Rejection(`Your role (${user.role}) cannot add or change ${c.label.toLowerCase()}s.`);
      const prevRow = isCF ? db.prepare('SELECT * FROM custom_fields WHERE id=? AND scope=?').get(id, c.customField) : sel[c.table].get(id);
      const prev = prevRow ? parse(prevRow) : null;
      const next = extractFiles(JSON.parse(JSON.stringify(rec)), user);
      if (JSON.stringify(next).length > 400000) throw new Rejection('Record is too large.');
      if (prev && same(prev, next)) return;                       // no-op
      if (!isCF) validateRecord(name, { user, prev, next });
      const now = nowStamp();
      if (isCF) {
        if (prev) db.prepare('UPDATE custom_fields SET data=?,updated_by=?,updated_at=?,version=version+1 WHERE id=?').run(JSON.stringify(next), user.username, now, id);
        else db.prepare('INSERT INTO custom_fields(id,scope,data,created_by) VALUES (?,?,?,?)').run(id, c.customField, JSON.stringify(next), user.username);
      } else if (prev) upd[c.table].run(...cols(next), JSON.stringify(next), user.username, now, id);
      else ins[c.table].run(id, ...cols(next), JSON.stringify(next), user.username, user.username, now);
      const label = next.pos || next.imei || next.name || next.label || id;
      audit(user.username, `${prev ? 'Edited' : 'Added'} ${c.label.toLowerCase()} ${label}`, { collection: name, recordId: id, ip });
    });
  }
  for (const id of change.delete || []) {
    one(String(id), () => {
      if (!can(c.del, user)) throw new Rejection(`Your role (${user.role}) cannot delete ${c.label.toLowerCase()}s.`);
      const row = isCF ? db.prepare('SELECT * FROM custom_fields WHERE id=? AND scope=?').get(id, c.customField) : sel[c.table].get(id);
      if (!row) return;
      if (name === 'fieldDeployments') throw new Rejection('Shipment records cannot be deleted.');
      if (isCF) db.prepare('DELETE FROM custom_fields WHERE id=?').run(id); else del[c.table].run(id);
      const p = parse(row);
      audit(user.username, `Deleted ${c.label.toLowerCase()} ${p.pos || p.imei || p.name || id}`, { collection: name, recordId: id, ip });
    });
  }
  return results;
}

// ---- messages (shipment notices) ----
function readMessages(user) {
  return db.prepare('SELECT * FROM messages ORDER BY rowid DESC LIMIT 500').all()
    .map(m => ({ id: m.id, recordId: m.record_id, kind: m.kind || undefined, msg: m.msg, roles: JSON.parse(m.roles), seenBy: JSON.parse(m.seen_by) }))
    .filter(m => m.roles.includes(user.role) || user.role === 'Admin');
}
function applyMessages(list, user, ip) {
  const results = [];
  for (const m of list || []) {
    try {
      if (!m || typeof m.id !== 'string') throw new Rejection('Bad message.');
      const row = db.prepare('SELECT * FROM messages WHERE id=?').get(m.id);
      if (row) {
        // only effect allowed on an existing message: add yourself to "seen by"
        if (!JSON.parse(row.roles).includes(user.role) && user.role !== 'Admin') throw new Rejection('No access to this message.');
        const seen = new Set(JSON.parse(row.seen_by));
        if (Array.isArray(m.seenBy) && m.seenBy.includes(user.username)) seen.add(user.username);
        db.prepare('UPDATE messages SET seen_by=? WHERE id=?').run(JSON.stringify([...seen]), m.id);
      } else {
        if (!can(C.fieldDeployments.write, user)) throw new Rejection('Your role cannot send shipment notices.');
        if (!has(m.msg) || String(m.msg).length > 600) throw new Rejection('Message text is required (max 600 characters).');
        if (!Array.isArray(m.roles) || !m.roles.length || m.roles.some(r => !require('./collections').ROLES.includes(r))) throw new Rejection('Invalid recipients.');
        if (m.recordId && !sel['field_deployments']) stmts('field_deployments');
        if (m.recordId && !sel['field_deployments'].get(m.recordId)) throw new Rejection('That shipment record does not exist.');
        db.prepare('INSERT INTO messages(id,record_id,kind,msg,roles,seen_by,created_by) VALUES (?,?,?,?,?,?,?)')
          .run(m.id, m.recordId || null, m.kind === 'ack' ? 'ack' : null, String(m.msg), JSON.stringify(m.roles), '[]', user.username);
      }
      results.push({ id: m.id, ok: true });
    } catch (e) { results.push({ id: m && m.id, ok: false, error: e instanceof Rejection ? e.message : 'Server error.' }); }
  }
  return results;
}

// ---- settings ----
function readSettings() {
  const out = {};
  for (const r of db.prepare('SELECT key,value FROM settings').all()) out[r.key] = JSON.parse(r.value);
  return out;
}
function applySettings(obj, user, ip) {
  const results = [];
  for (const [k, v] of Object.entries(obj || {})) {
    if (!SETTINGS[k]) { results.push({ id: k, ok: false, error: 'Unknown setting.' }); continue; }
    if (!SETTINGS[k].write.includes(user.role)) { results.push({ id: k, ok: false, error: 'Your role cannot change this value.' }); continue; }
    if (k === 'stockBalance' && !(typeof v === 'number' && isFinite(v))) { results.push({ id: k, ok: false, error: 'Must be a number.' }); continue; }
    if (k === 'spareParts' && (typeof v !== 'object' || v === null || Object.values(v).some(x => typeof x !== 'number' || !isFinite(x)))) { results.push({ id: k, ok: false, error: 'Must be a map of numbers.' }); continue; }
    const prev = db.prepare('SELECT value FROM settings WHERE key=?').get(k);
    if (prev && prev.value === JSON.stringify(v)) { results.push({ id: k, ok: true }); continue; }
    db.prepare('INSERT INTO settings(key,value,updated_by,updated_at) VALUES (?,?,?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value,updated_by=excluded.updated_by,updated_at=excluded.updated_at')
      .run(k, JSON.stringify(v), user.username, nowStamp());
    audit(user.username, `Updated ${k === 'stockBalance' ? 'stock balance' : 'spare-part stock'}`, { ip });
    results.push({ id: k, ok: true });
  }
  return results;
}

module.exports = { readCollection, applyChange, readMessages, applyMessages, readSettings, applySettings };
