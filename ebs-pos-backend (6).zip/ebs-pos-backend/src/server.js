const path = require('path');
const crypto = require('crypto');
const fs = require('fs');
const express = require('express');
const helmet = require('helmet');
const cookieParser = require('cookie-parser');
const rateLimit = require('express-rate-limit');
const cfg = require('./config');
const isSuperName = name => cfg.superAdmins.includes(String(name || '').toLowerCase());
const isSuper = isSuperName;
const iSuper = u => !!u && isSuperName(u.username);
const { db, audit } = require('./db');
const { C, ROLES } = require('./collections');
const auth = require('./auth');
const rec = require('./records');
const { ensureSeed } = require('./seed');

const app = express();
app.set('trust proxy', 1);
app.disable('x-powered-by');
app.use(helmet({
  contentSecurityPolicy: { directives: {
    defaultSrc: ["'self'"], scriptSrc: ["'self'", "'unsafe-inline'", 'https://cdnjs.cloudflare.com'],
    styleSrc: ["'self'", "'unsafe-inline'", 'https://fonts.googleapis.com'], fontSrc: ["'self'", 'https://fonts.gstatic.com', 'data:'],
    imgSrc: ["'self'", 'data:', 'blob:'], connectSrc: ["'self'"], frameAncestors: ["'none'"],
    upgradeInsecureRequests: cfg.cookieSecure ? [] : null,
  } },
  crossOriginEmbedderPolicy: false,
  hsts: cfg.cookieSecure ? undefined : false,
}));
if (cfg.corsOrigin) app.use((req, res, next) => {
  if (req.headers.origin === cfg.corsOrigin) { res.set({ 'Access-Control-Allow-Origin': cfg.corsOrigin, 'Access-Control-Allow-Credentials': 'true', 'Access-Control-Allow-Headers': 'Content-Type,X-CSRF-Token', 'Access-Control-Allow-Methods': 'GET,POST,PATCH,DELETE', Vary: 'Origin' }); }
  if (req.method === 'OPTIONS') return res.sendStatus(204); next();
});
app.use(express.json({ limit: '25mb' }));
app.use(cookieParser());

const COOKIE = 'ebs_session';
const cookieOpts = { httpOnly: true, sameSite: cfg.corsOrigin ? 'none' : 'strict', secure: cfg.cookieSecure, path: '/' };
const fail = (res, code, error) => res.status(code).json({ error });

// ---------- auth middleware ----------
function requireAuth(req, res, next) {
  const s = auth.sessionFrom(req.cookies[COOKIE]);
  if (!s) return fail(res, 401, 'Please log in.');
  if (s.expired) { res.clearCookie(COOKIE, cookieOpts); const u = db.prepare('SELECT username FROM users WHERE id=?').get(s.userId); if (u) audit(u.username, 'Session expired after inactivity', { ip: req.ip }); return fail(res, 401, 'You were logged out after 15 minutes of inactivity.'); }
  if (req.method !== 'GET' && req.method !== 'HEAD') {
    const t = req.get('X-CSRF-Token') || '';
    if (t.length !== s.csrf.length || !crypto.timingSafeEqual(Buffer.from(t), Buffer.from(s.csrf))) return fail(res, 403, 'Invalid security token. Refresh the page.');
  }
  req.session = s; req.user = s.user; next();
}
const requireRole = (...roles) => (req, res, next) => roles.includes(req.user.role) ? next() : fail(res, 403, 'You do not have permission to do that.');
const noMustChange = (req, res, next) => req.user.mustChangePassword ? fail(res, 403, 'You must change your temporary password first.') : next();

// ---------- routes ----------
const api = express.Router();
api.get('/health', (req, res) => res.json({ ok: true, app: 'ebs-pos', time: new Date().toISOString() }));

const loginLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 100, standardHeaders: true, legacyHeaders: false, message: { error: 'Too many login attempts from this network. Try again later.' } });
api.post('/auth/login', loginLimiter, (req, res) => {
  const r = auth.login(req.body && req.body.username, req.body && req.body.password, req);
  if (r.error) return fail(res, r.code, r.error);
  res.cookie(COOKIE, r.token, cookieOpts);
  res.json({ user: r.user, csrf: r.csrf });
});
api.post('/auth/logout', requireAuth, (req, res) => {
  audit(req.user.username, req.body && req.body.reason ? String(req.body.reason).slice(0, 120) : 'Logged out', { ip: req.ip });
  auth.destroy(req.cookies[COOKIE]); res.clearCookie(COOKIE, cookieOpts); res.json({ ok: true });
});
api.get('/auth/me', requireAuth, (req, res) => res.json({ user: req.user, csrf: req.session.csrf }));
api.post('/auth/change-password', requireAuth, (req, res) => {
  const { currentPassword, newPassword } = req.body || {};
  const row = db.prepare('SELECT * FROM users WHERE id=?').get(req.user.id);
  if (!auth.verify(String(currentPassword || ''), row.password_hash)) return fail(res, 400, 'Your current password is incorrect.');
  const p = auth.passwordProblem(newPassword); if (p) return fail(res, 400, p);
  if (newPassword === currentPassword) return fail(res, 400, 'Choose a password different from the current one.');
  db.prepare("UPDATE users SET password_hash=?, must_change_password=0, updated_at=datetime('now') WHERE id=?").run(auth.hash(newPassword), row.id);
  audit(row.username, 'Changed their own password', { ip: req.ip });
  res.json({ ok: true });
});

// ----- users (Admin) -----
const users = express.Router();
users.use(requireAuth, requireRole('Admin'), noMustChange);
const iAmSuper = req => isSuper(req.user.username);
users.param('id', (req, res, next, id) => { const u = db.prepare('SELECT username FROM users WHERE id=?').get(id); if (u && isSuper(u.username) && !iAmSuper(req)) return fail(res, 404, 'User not found.'); next(); });
const ZONE_ROLES = ['HOC', 'Commercial'];
function userInput(b, creating) {
  const o = {};
  if (creating || b.fullName !== undefined) { o.fullName = String(b.fullName || '').trim(); if (!o.fullName) throw new Error('Full name is required.'); }
  if (creating || b.role !== undefined) { if (!ROLES.includes(b.role)) throw new Error('Choose a valid role.'); o.role = b.role; }
  if (b.email !== undefined) o.email = String(b.email).trim().slice(0, 200);
  if (b.status !== undefined) { if (!['Active', 'Suspended'].includes(b.status)) throw new Error('Invalid status.'); o.status = b.status; }
  return o;
}
users.get('/', (req, res) => res.json({ users: db.prepare('SELECT * FROM users ORDER BY created_at DESC, rowid DESC').all().filter(u => iAmSuper(req) || !isSuper(u.username)).map(auth.publicUser) }));
users.post('/', (req, res) => {
  try {
    const b = req.body || {}, o = userInput(b, true), name = String(b.username || '').trim().toLowerCase();
    if (!/^[a-z0-9._-]{2,40}$/.test(name)) throw new Error('Username must be 2–40 letters, numbers, dot, dash or underscore.');
    const p = auth.passwordProblem(b.password); if (p) throw new Error('Temporary password must be at least 8 characters.');
    if (ZONE_ROLES.includes(o.role) && !(Array.isArray(b.zones) && b.zones.length)) throw new Error('Select at least one zone for this role.');
    if (db.prepare('SELECT 1 FROM users WHERE username=?').get(name) || (isSuper(name) && !iAmSuper(req))) throw new Error('That username is already taken.');
    const id = 'u-' + crypto.randomBytes(6).toString('hex');
    db.prepare('INSERT INTO users(id,username,password_hash,role,full_name,email,status,zones,must_change_password) VALUES (?,?,?,?,?,?,?,?,1)')
      .run(id, name, auth.hash(b.password), o.role, o.fullName, o.email || '', 'Active', ZONE_ROLES.includes(o.role) ? JSON.stringify(b.zones.map(String)) : null);
    audit(req.user.username, `Created user ${name} (${o.role})`, { ip: req.ip });
    res.status(201).json({ user: auth.publicUser(db.prepare('SELECT * FROM users WHERE id=?').get(id)) });
  } catch (e) { fail(res, 400, e.message); }
});
users.patch('/:id', (req, res) => {
  try {
    const u = db.prepare('SELECT * FROM users WHERE id=?').get(req.params.id); if (!u) return fail(res, 404, 'User not found.');
    const b = req.body || {}, o = userInput(b, false), role = o.role || u.role;
    if (u.id === req.user.id && (role !== 'Admin' || o.status === 'Suspended')) throw new Error("You can't remove your own Admin access or suspend yourself.");
    if (u.role === 'Admin' && (role !== 'Admin' || o.status === 'Suspended') && db.prepare("SELECT COUNT(*) c FROM users WHERE role='Admin' AND status='Active'").get().c < 2) throw new Error('There must be at least one active Admin.');
    let zones = u.zones;
    if (ZONE_ROLES.includes(role)) { const z = b.zones !== undefined ? b.zones : (u.zones ? JSON.parse(u.zones) : []); if (!Array.isArray(z) || !z.length) throw new Error('Select at least one zone for this role.'); zones = JSON.stringify(z.map(String)); } else zones = null;
    db.prepare("UPDATE users SET full_name=?,email=?,role=?,status=?,zones=?,updated_at=datetime('now') WHERE id=?")
      .run(o.fullName || u.full_name, o.email !== undefined ? o.email : u.email, role, o.status || u.status, zones, u.id);
    if ((o.status && o.status !== 'Active') || role !== u.role) auth.destroyAllFor(u.id);
    audit(req.user.username, o.status && o.status !== u.status ? `${o.status === 'Suspended' ? 'Suspended' : 'Reactivated'} user ${u.username}` : `Edited user account ${u.username}`, { ip: req.ip });
    res.json({ user: auth.publicUser(db.prepare('SELECT * FROM users WHERE id=?').get(u.id)) });
  } catch (e) { fail(res, 400, e.message); }
});
users.post('/:id/reset-password', (req, res) => {
  const u = db.prepare('SELECT * FROM users WHERE id=?').get(req.params.id); if (!u) return fail(res, 404, 'User not found.');
  const p = auth.passwordProblem(req.body && req.body.password); if (p) return fail(res, 400, 'New password must be at least 8 characters.');
  db.prepare("UPDATE users SET password_hash=?, must_change_password=1, failed_attempts=0, locked=0, updated_at=datetime('now') WHERE id=?").run(auth.hash(req.body.password), u.id);
  auth.destroyAllFor(u.id);
  audit(req.user.username, `Reset password for user ${u.username}`, { ip: req.ip });
  res.json({ ok: true });
});
users.post('/:id/unlock', (req, res) => {
  const u = db.prepare('SELECT * FROM users WHERE id=?').get(req.params.id); if (!u) return fail(res, 404, 'User not found.');
  db.prepare('UPDATE users SET failed_attempts=0, locked=0 WHERE id=?').run(u.id);
  audit(req.user.username, `Unlocked user ${u.username}`, { ip: req.ip });
  res.json({ ok: true });
});
api.use('/users', users);

// ----- data sync -----
function snapshot(user, only) {
  const collections = {};
  for (const name of Object.keys(C)) if (!only || only.includes(name)) collections[name] = rec.readCollection(name, user);
  return collections;
}
api.get('/bootstrap', requireAuth, noMustChange, (req, res) => {
  const directory = db.prepare("SELECT id,username,full_name,role,status FROM users").all().filter(u => iSuper(req.user) || !isSuperName(u.username)).map(u => ({ id: u.id, username: u.username, fullName: u.full_name, role: u.role, status: u.status }));
  res.json({
    user: req.user, collections: snapshot(req.user), settings: rec.readSettings(), messages: rec.readMessages(req.user),
    directory, ...(req.user.role === 'Admin' ? { users: db.prepare('SELECT * FROM users ORDER BY rowid DESC').all().filter(u => iSuper(req.user) || !isSuperName(u.username)).map(auth.publicUser), auditLog: auditRows(500, req.user) } : {}),
  });
});
const auditRows = (n, viewer) => {
  if (iSuper(viewer)) return db.prepare('SELECT time,user,action FROM audit_log ORDER BY id DESC LIMIT ?').all(n);
  const hide = cfg.superAdmins.length ? cfg.superAdmins : ['\u0000'];
  return db.prepare(`SELECT time,user,action FROM audit_log WHERE lower(user) NOT IN (${hide.map(() => '?').join(',')}) ORDER BY id DESC LIMIT ?`).all(...hide, n);
};
api.get('/collections/:name', requireAuth, noMustChange, (req, res) => C[req.params.name] ? res.json({ rows: rec.readCollection(req.params.name, req.user) }) : fail(res, 404, 'Unknown collection.'));
api.get('/audit', requireAuth, requireRole('Admin'), noMustChange, (req, res) => res.json({ auditLog: auditRows(Math.min(Number(req.query.limit) || 500, 5000), req.user) }));

api.post('/sync', requireAuth, noMustChange, (req, res) => {
  const b = req.body || {}, results = [], touched = new Set();
  const run = db.transaction(() => {
    for (const ch of Array.isArray(b.changes) ? b.changes : []) {
      const rs = rec.applyChange(String(ch.collection), ch, req.user, req.ip);
      rs.forEach(r => { r.collection = ch.collection; results.push(r); if (!r.ok) touched.add(ch.collection); });
    }
    if (b.messages) rec.applyMessages(b.messages, req.user, req.ip).forEach(r => { r.collection = 'messages'; results.push(r); });
    if (b.settings) rec.applySettings(b.settings, req.user, req.ip).forEach(r => { r.collection = 'settings'; results.push(r); if (!r.ok) touched.add('settings'); });
    if (Array.isArray(b.audit)) for (const a of b.audit.slice(0, 20)) if (typeof a === 'string' && /^(Exported|Downloaded|Printed|Restored|Opened)/.test(a)) audit(req.user.username, a.slice(0, 200), { ip: req.ip });
  });
  run();
  const out = { results };
  if (touched.size) { out.collections = snapshot(req.user, [...touched].filter(n => C[n])); if (touched.has('settings')) out.settings = rec.readSettings(); }
  out.messages = rec.readMessages(req.user);
  if (req.user.role === 'Admin') out.auditLog = auditRows(500, req.user);
  res.json(out);
});

api.get('/files/:id', requireAuth, (req, res) => {
  const f = db.prepare('SELECT * FROM files WHERE id=?').get(String(req.params.id).replace(/[^a-f0-9]/g, ''));
  if (!f) return fail(res, 404, 'File not found.');
  res.set({ 'Content-Type': f.mime, 'Content-Disposition': 'inline', 'X-Content-Type-Options': 'nosniff', 'Cache-Control': 'private, max-age=3600' });
  res.sendFile(path.join(cfg.dataDir, 'uploads', f.path));
});
// Admin: full JSON backup of every table (no password hashes)
api.get('/admin/backup', requireAuth, requireRole('Admin'), noMustChange, (req, res) => {
  const tables = { ...snapshot(req.user), users: db.prepare('SELECT * FROM users').all().filter(u => iSuper(req.user) || !isSuperName(u.username)).map(auth.publicUser), auditLog: auditRows(100000, req.user), messages: rec.readMessages(req.user), settings: rec.readSettings() };
  audit(req.user.username, 'Downloaded full data backup', { ip: req.ip });
  res.set('Content-Disposition', `attachment; filename="ebs-backup-${new Date().toISOString().slice(0, 10)}.json"`);
  res.json({ generated_at: new Date().toISOString(), tables });
});
api.use((req, res) => fail(res, 404, 'Not found.'));
app.use('/api', api);

// ---------- static front end ----------
app.use(express.static(cfg.publicDir, { index: 'index.html', maxAge: 0, setHeaders: r => r.setHeader('Cache-Control', 'no-cache') }));
app.use((err, req, res, next) => {
  if (err && err.type === 'entity.too.large') return fail(res, 413, 'That upload is too large.');
  if (err instanceof SyntaxError) return fail(res, 400, 'Bad request.');
  console.error(err); fail(res, 500, 'Something went wrong on the server.');
});

if (require.main === module) {
  ensureSeed();
  setInterval(() => { try { auth.purgeExpired(); } catch (_) {} }, 5 * 60 * 1000).unref();
  app.listen(cfg.port, () => console.log(`Elephant Bet POS server listening on http://localhost:${cfg.port}`));
}
module.exports = app;
