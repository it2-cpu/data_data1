// Runs the browser-level test (real front end in jsdom + real server + SQLite).
const test = require('node:test'), assert = require('node:assert/strict'), { spawnSync } = require('child_process'), path = require('path');
test('front end + back end work together end to end', () => {
  const r = spawnSync(process.execPath, [path.join(__dirname, 'e2e-browser.js')], { encoding: 'utf8', timeout: 120000 });
  assert.match(r.stdout, /ALL PASS/, r.stdout.split('\n').filter(l => /false|FAIL|ERROR/.test(l)).join('\n') + r.stderr.slice(-500));
});
