// End-to-end: the real front end (jsdom) talking to the real backend (SQLite).
const fs = require('fs'), os = require('os'), path = require('path');
const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'ebs-e2e-'));
process.env.DATA_DIR = tmp; process.env.SEED_DEMO_USERS = '1';
const BE = require('path').join(__dirname, '..', 'src') + '/';
const app = require(BE + 'server'); const { ensureSeed } = require(BE + 'seed'); const { db } = require(BE + 'db');
ensureSeed();
const { JSDOM } = require('jsdom');
const html = fs.readFileSync(process.env.APP_HTML || require('path').join(__dirname, '..', 'public', 'index.html'), 'utf8');
const sleep = ms => new Promise(r => setTimeout(r, ms));

async function boot(base) {
  let jar = '';
  const dom = new JSDOM(html, { runScripts: 'dangerously', resources: 'usable', pretendToBeVisual: true, url: base + '/',
    beforeParse(w) {
      w.fetch = async (u, o = {}) => {
        const h = Object.assign({}, o.headers); if (jar) h.Cookie = jar;
        const r = await fetch(new URL(u, base).href, { method: o.method, headers: h, body: o.body });
        const sc = r.headers.get('set-cookie'); if (sc) { const kv = sc.split(';')[0]; jar = /=;?$/.test(kv) || /Expires=Thu, 01 Jan 1970/i.test(sc) ? '' : kv; }
        return r;
      };
    } });
  const { window } = dom, doc = window.document;
  for (let i = 0; i < 100 && !doc.querySelector('.login-card'); i++) await sleep(50);
  const H = {
    window, doc,
    text() { const c = doc.body.cloneNode(true); c.querySelectorAll('script,style').forEach(n => n.remove()); return c.textContent; },
    setVal(el, v) { Object.getOwnPropertyDescriptor(Object.getPrototypeOf(el), 'value').set.call(el, v); el.dispatchEvent(new window.Event(el.tagName === 'SELECT' ? 'change' : 'input', { bubbles: true })); },
    click(el) { el.dispatchEvent(new window.MouseEvent('click', { bubbles: true })); },
    btn(re) { return Array.from(doc.querySelectorAll('button')).find(b => re.test(b.textContent)); },
    nav(label) { return Array.from(doc.querySelectorAll('.nav-item')).find(b => b.textContent.trim() === label); },
    field(label) { const l = Array.from(doc.querySelectorAll('.field label')).find(x => x.textContent.trim().replace(/\*$/, '').trim().startsWith(label)); return l && l.parentElement.querySelector('input,select'); },
    set(label, v) { const f = H.field(label); if (!f) throw new Error('no field ' + label); H.setVal(f, v); },
    async login(u, p) { const prev = doc.querySelector('.login-error')?.textContent || ''; const i = doc.querySelectorAll('.login-card input'); H.setVal(i[0], u); H.setVal(i[1], p); await sleep(50); H.click(doc.querySelector('.login-card button.btn-primary')); for (let k = 0; k < 40; k++) { await sleep(100); if (doc.querySelector('.shell') || doc.querySelector('.modal')) break; const e = doc.querySelector('.login-error')?.textContent || ''; if (e && e !== prev) break; } await sleep(200); },
    async logout() { H.click(H.btn(/Log ?out/i)); await sleep(300); },
  };
  return H;
}

(async () => {
  const server = app.listen(0); const base = 'http://127.0.0.1:' + server.address().port;
  const R = {};
  // ---- 1. app detects the server and uses it
  let A = await boot(base); await sleep(200);
  R.apiMode = A.window.__EBS_API__ === true; console.log('API mode detected?', R.apiMode);
  await A.login('itsupervisor', 'WRONG'); 
  R.wrongMsg = /attempt\(s\) remaining/.test(A.doc.querySelector('.login-error')?.textContent || ''); console.log('Server-side wrong-password message?', R.wrongMsg);
  await A.login('itsupervisor', 'ITSup@2026');
  R.loggedIn = !!A.doc.querySelector('.shell'); console.log('IT Supervisor logged in via server?', R.loggedIn);
  // ---- 2. no demo data leaks in; add a record through the normal screen
  A.click(A.nav('Deployment Records')); await sleep(200);
  A.click(Array.from(A.doc.querySelectorAll('.nav-item')).find(b => /^Deployment Records$/.test(b.textContent.trim()))); await sleep(250);
  R.noDemo = !A.text().includes('POS-1001'); console.log('No demo seed rows shown?', R.noDemo);
  A.click(A.btn(/Add Deployment/i)); await sleep(200);
  A.set('POS Number', 'POS-E2E1'); A.set('Machine IMEI', '356938035649777'); A.set('Serial Number', 'SNE2E1'); A.set('Date of Deployment', '2026-10-01'); A.set('SIM Number', '77123456'); A.set('Zone', 'Freetown'); await sleep(100); 
  const k = A.field('Kiosk'); A.setVal(k, Array.from(k.options).find(o => o.value)?.value); await sleep(100);
  A.click(Array.from(A.doc.querySelectorAll('.modal button')).find(b => /Save/i.test(b.textContent))); await sleep(1500);
  const row = db.prepare("SELECT * FROM deployments WHERE pos='POS-E2E1'").get();
  R.saved = !!row && JSON.parse(row.data).imei === '356938035649777' && row.created_by === 'itsupervisor'; console.log('Record saved to SQLite by the server?', R.saved);
  R.audited = !!db.prepare("SELECT 1 FROM audit_log WHERE user='itsupervisor' AND action LIKE 'Added deployment record POS-E2E1%'").get(); console.log('Server wrote the audit entry?', R.audited);
  // ---- 3. persistence: a brand-new browser sees it
  await A.logout();
  R.loggedOut = !!A.doc.querySelector('.login-card'); console.log('Logged out to login screen?', R.loggedOut);
  const B = await boot(base); await sleep(200);
  await B.login('viewer', 'Viewer@2026');
  B.click(B.nav('Deployment Records')); await sleep(200);
  B.click(Array.from(B.doc.querySelectorAll('.nav-item')).find(b => /^Deployment Records$/.test(b.textContent.trim()))); await sleep(300);
  R.persisted = B.text().includes('POS-E2E1'); console.log('Viewer (new browser) sees the record?', R.persisted);
  R.viewerReadOnly = !B.btn(/Add Deployment/i); console.log('Viewer has no Add button?', R.viewerReadOnly);
  // data from one user must not remain after logout
  await B.logout(); await sleep(200);
  R.cleared = !B.text().includes('POS-E2E1'); console.log('Nothing left on screen after logout?', R.cleared);
  // ---- 4. Admin: users + audit come from the server
  await B.login('admin1', 'Password@123!');
  B.click(B.nav('User Management')); await sleep(400);
  R.users = /itsupervisor/.test(B.text()) && !/ITSup@2026|Password@123!/.test(B.text()); console.log('Admin sees users from server (no passwords)?', R.users);
  B.click(B.btn(/Add User/i)); await sleep(200);
  B.set('Full Name', 'E2E Person'); B.set('Username', 'e2e.person'); B.set('Temporary Password', 'Temp12345');
  const inputs = Array.from(B.doc.querySelectorAll('.modal input')); 
  B.click(Array.from(B.doc.querySelectorAll('.modal button')).find(b => /Create|Save|Add/i.test(b.textContent) && !/Cancel/i.test(b.textContent))); await sleep(1200);
  const u = db.prepare("SELECT * FROM users WHERE username='e2e.person'").get();
  R.userMade = !!u && /^\$2[aby]\$/.test(u.password_hash) && u.must_change_password === 1; console.log('New user stored with bcrypt hash + must-change flag?', R.userMade);
  B.click(B.nav('Audit Log')); await sleep(400);
  R.auditUi = /Added deployment record POS-E2E1/.test(B.text()); console.log('Audit screen shows server entries?', R.auditUi);
  await B.logout();
  // ---- 5. forced password change for the new user, then normal use
  await B.login('e2e.person', 'Temp12345'); await sleep(300);
  const forced = B.doc.querySelector('.modal'); R.forced = !!forced && /password/i.test(forced.textContent); console.log('Temporary-password user is forced to change it?', R.forced);
  const pw = Array.from(B.doc.querySelectorAll('.modal input')); 
  if (pw.length >= 3) { B.setVal(pw[0], 'Temp12345'); B.setVal(pw[1], 'Brand#New99'); B.setVal(pw[2], 'Brand#New99'); }
  await sleep(100); B.click(Array.from(B.doc.querySelectorAll('.modal button')).find(b => /Change|Save|Update|Submit/i.test(b.textContent))); await sleep(1500);
  R.afterChange = !!B.doc.querySelector('.shell') && !B.doc.querySelector('.modal'); console.log('After changing password the app opens?', R.afterChange);
  // ---- 6. when the server refuses a change, the screen rolls back and says why
  const C = await boot(base); await sleep(200);
  const realFetch = C.window.fetch; let rejected = false;
  C.window.fetch = async (u, o = {}) => {
    if (!rejected && String(u).endsWith('/api/sync') && o.body && JSON.parse(o.body).changes.some(c => c.collection === 'deployments' && c.upsert.length)) {
      rejected = true; const id = JSON.parse(o.body).changes.find(c => c.collection === 'deployments').upsert[0].id;
      return new Response(JSON.stringify({ results: [{ collection: 'deployments', id, ok: false, error: 'Server says no (test).' }], collections: { deployments: [] } }), { status: 200, headers: { 'Content-Type': 'application/json' } });
    } return realFetch(u, o);
  };
  await C.login('itsupervisor', 'ITSup@2026');
  C.click(C.nav('Deployment Records')); await sleep(200);
  C.click(Array.from(C.doc.querySelectorAll('.nav-item')).find(b => /^Deployment Records$/.test(b.textContent.trim()))); await sleep(300);
  C.click(C.btn(/Add Deployment/i)); await sleep(200);
  C.set('POS Number', 'POS-REJ1'); C.set('Machine IMEI', '356938035649888'); C.set('Serial Number', 'SNREJ1'); C.set('Date of Deployment', '2026-10-02'); C.set('SIM Number', '77123457'); C.set('Zone', 'Freetown'); await sleep(100);
  const k2 = C.field('Kiosk'); C.setVal(k2, Array.from(k2.options).find(o => o.value)?.value); await sleep(100);
  C.click(Array.from(C.doc.querySelectorAll('.modal button')).find(b => /Save/i.test(b.textContent))); await sleep(1500);
  R.rejectToast = /Server says no \(test\)\./.test(C.text()); console.log('Server refusal shown to the user?', R.rejectToast);
  R.rolledBack = !C.text().includes('POS-REJ1') && !db.prepare("SELECT 1 FROM deployments WHERE pos='POS-REJ1'").get(); console.log('Refused record removed from screen, not in database?', R.rolledBack);
  const ok = Object.values(R).every(Boolean);
  console.log(ok ? 'ALL PASS' : 'FAIL ' + JSON.stringify(R)); process.exit(ok ? 0 : 1);
})().catch(e => { console.error('ERROR', e); process.exit(1); });
setTimeout(() => { console.log('GLOBAL TIMEOUT'); process.exit(2); }, 90000);
