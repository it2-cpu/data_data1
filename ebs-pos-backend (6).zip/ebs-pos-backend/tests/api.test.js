const test = require('node:test');
const assert = require('node:assert/strict');
const os = require('os'), path = require('path'), fs = require('fs');
const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'ebs-'));
process.env.DATA_DIR = tmp; process.env.SEED_DEMO_USERS = '1'; process.env.SESSION_IDLE_MINUTES = '15';
const app = require('../src/server');
const { ensureSeed } = require('../src/seed');
const { db } = require('../src/db');
ensureSeed();

let base, server;
test.before(() => new Promise(r => { server = app.listen(0, () => { base = 'http://127.0.0.1:' + server.address().port + '/api'; r(); }); }));
test.after(() => server.close());

class Client {
  constructor() { this.cookie = ''; this.csrf = ''; }
  async req(method, url, body) {
    const h = { 'Content-Type': 'application/json' }; if (this.cookie) h.Cookie = this.cookie; if (this.csrf) h['X-CSRF-Token'] = this.csrf;
    const r = await fetch(base + url, { method, headers: h, body: body ? JSON.stringify(body) : undefined });
    const sc = r.headers.get('set-cookie'); if (sc) this.cookie = sc.split(';')[0];
    let j = null; try { j = await r.json(); } catch (_) {}
    return { status: r.status, body: j, headers: r.headers };
  }
  async login(u, p) { const r = await this.req('POST', '/auth/login', { username: u, password: p }); if (r.status === 200) this.csrf = r.body.csrf; return r; }
  sync(changes, extra = {}) { return this.req('POST', '/sync', { changes, ...extra }); }
}
const as = async (u, p) => { const c = new Client(); const r = await c.login(u, p); assert.equal(r.status, 200, u + ' login'); return c; };
const dep = (o = {}) => ({ id: 'd-' + Math.random().toString(36).slice(2, 8), pos: 'POS-9001', imei: '356938035649001', serial: 'SN9001', sim: '+232 77123456', date: '2026-10-01', zone: 'Freetown', kiosk: 'K1', ...o });

test('health + unauthenticated access is refused', async () => {
  const c = new Client();
  assert.equal((await c.req('GET', '/health')).status, 200);
  assert.equal((await c.req('GET', '/bootstrap')).status, 401);
  assert.equal((await c.req('POST', '/sync', {})).status, 401);
});

test('login: cookie is HttpOnly, password never returned, wrong password counted', async () => {
  const c = new Client();
  const r = await c.login('admin1', 'Password@123!');
  assert.equal(r.status, 200);
  assert.match(r.headers.get('set-cookie'), /HttpOnly/i);
  assert.match(r.headers.get('set-cookie'), /SameSite=Strict/i);
  assert.equal(JSON.stringify(r.body).includes('Password@123!'), false);
  assert.equal(r.body.user.role, 'Admin');
  const b = await c.req('GET', '/bootstrap');
  assert.equal(JSON.stringify(b.body).toLowerCase().includes('password_hash'), false);
  assert.ok(b.body.users.length >= 7);
});

test('passwords are stored hashed (bcrypt)', () => {
  const r = db.prepare("SELECT password_hash h FROM users WHERE username='admin1'").get();
  assert.match(r.h, /^\$2[aby]\$/); assert.notEqual(r.h, 'Password@123!');
});

test('lockout after 5 failures, server-side; Admin unlock restores access', async () => {
  const c = new Client();
  let r; for (let i = 0; i < 5; i++) r = await c.login('viewer', 'wrong');
  assert.match(r.body.error, /locked/i);
  assert.equal((await c.login('viewer', 'Viewer@2026')).status, 423);   // even the right password is refused
  const admin = await as('admin1', 'Password@123!');
  const id = (await admin.req('GET', '/users')).body.users.find(u => u.username === 'viewer').id;
  assert.equal((await admin.req('POST', `/users/${id}/unlock`)).status, 200);
  assert.equal((await new Client().login('viewer', 'Viewer@2026')).status, 200);
});

test('CSRF token is required on writes', async () => {
  const c = await as('itsupervisor', 'ITSup@2026');
  c.csrf = 'bad';
  assert.equal((await c.sync([{ collection: 'deployments', upsert: [dep()] }])).status, 403);
});

test('session expires after idle time', async () => {
  const c = await as('supervisor', 'Supervisor@2026');
  db.prepare('UPDATE sessions SET last_seen = last_seen - ?').run(16 * 60 * 1000);
  const r = await c.req('GET', '/bootstrap');
  assert.equal(r.status, 401); assert.match(r.body.error, /15 minutes/);
});

test('RBAC: Viewer / Logistic / HOC cannot write deployments; IT can', async () => {
  for (const [u, p] of [['viewer', 'Viewer@2026'], ['logistics', 'Logistics@2026'], ['hoc', 'Hoc@2026']]) {
    const c = await as(u, p); const r = await c.sync([{ collection: 'deployments', upsert: [dep()] }]);
    assert.equal(r.body.results[0].ok, false, u); assert.match(r.body.results[0].error, /cannot/i);
  }
  const it = await as('itsupervisor', 'ITSup@2026');
  const d = dep({ id: 'd-it-1' });
  const r = await it.sync([{ collection: 'deployments', upsert: [d] }]);
  assert.equal(r.body.results[0].ok, true);
  const b = await it.req('GET', '/bootstrap');
  assert.ok(b.body.collections.deployments.some(x => x.id === 'd-it-1'));
});

test('business rules: IMEI = 15 digits, SIM = +232 + 8 digits, required fields', async () => {
  const it = await as('itsupervisor', 'ITSup@2026');
  let r = await it.sync([{ collection: 'deployments', upsert: [dep({ imei: '12345678901234' })] }]);
  assert.match(r.body.results[0].error, /15 digits/);
  r = await it.sync([{ collection: 'deployments', upsert: [dep({ imei: '1234567890123456' })] }]);
  assert.match(r.body.results[0].error, /15 digits/);
  r = await it.sync([{ collection: 'deployments', upsert: [dep({ sim: '23277123456' })] }]);
  assert.match(r.body.results[0].error, /\+232/);
  r = await it.sync([{ collection: 'deployments', upsert: [dep({ serial: '' })] }]);
  assert.match(r.body.results[0].error, /Serial/);
});

test('delete is Admin-only and written to the audit log', async () => {
  const it = await as('itsupervisor', 'ITSup@2026');
  await it.sync([{ collection: 'deployments', upsert: [dep({ id: 'd-del' })] }]);
  assert.equal((await it.sync([{ collection: 'deployments', delete: ['d-del'] }])).body.results[0].ok, false);
  const ad = await as('admin1', 'Password@123!');
  assert.equal((await ad.sync([{ collection: 'deployments', delete: ['d-del'] }])).body.results[0].ok, true);
  const log = (await ad.req('GET', '/audit')).body.auditLog.map(a => a.action).join('|');
  assert.match(log, /Added deployment record POS-9001/); assert.match(log, /Deleted deployment record/);
  assert.equal((await it.req('GET', '/audit')).status, 403);
});

test('shipment workflow: roles, confirmations, lock, messages', async () => {
  const lg = await as('logistics', 'Logistics@2026');
  const fd = { id: 'fd-1', pos: 'POS-9001', imei: '356938035649001', serial: 'SN9001', name: 'Shop', shipDate: '2026-10-02', quantity: '1', zone: 'Freetown', town: 'Kissy' };
  let r = await lg.sync([{ collection: 'fieldDeployments', upsert: [fd] }], { messages: [{ id: 'm-1', recordId: 'fd-1', msg: 'Machines have been shipped', roles: ['Supervisor', 'HOC'], seenBy: [] }] });
  assert.ok(r.body.results.every(x => x.ok), JSON.stringify(r.body.results));
  // HOC cannot set shipDate, can set receivedDate; Logistic can't set receivedDate
  const hoc = await as('hoc', 'Hoc@2026');
  r = await hoc.sync([{ collection: 'fieldDeployments', upsert: [{ ...fd, shipDate: '2026-01-01' }] }]); assert.equal(r.body.results[0].ok, false);
  r = await lg.sync([{ collection: 'fieldDeployments', upsert: [{ ...fd, receivedDate: '2026-10-03' }] }]); assert.equal(r.body.results[0].ok, false);
  r = await hoc.sync([{ collection: 'fieldDeployments', upsert: [{ ...fd, receivedDate: '2026-10-03', deployDate: '2026-10-04' }] }]); assert.equal(r.body.results[0].ok, true);
  // Messages are role-filtered
  assert.ok((await hoc.req('GET', '/bootstrap')).body.messages.some(m => m.id === 'm-1'));
  assert.equal((await (await as('viewer', 'Viewer@2026')).req('GET', '/bootstrap')).body.messages.length, 0);
  // Confirmations
  const sup = await as('supervisor', 'Supervisor@2026');
  let cur = { ...fd, receivedDate: '2026-10-03', deployDate: '2026-10-04' };
  r = await sup.sync([{ collection: 'fieldDeployments', upsert: [{ ...cur, shipConfirmedBy: 'someoneelse', shipConfirmedAt: 'x' }] }]); assert.equal(r.body.results[0].ok, false);
  r = await sup.sync([{ collection: 'fieldDeployments', upsert: [{ ...cur, shipConfirmedBy: 'supervisor', shipConfirmedAt: 'x' }] }]); assert.equal(r.body.results[0].ok, true);
  cur = { ...cur, shipConfirmedBy: 'supervisor', shipConfirmedAt: 'x' };
  r = await hoc.sync([{ collection: 'fieldDeployments', upsert: [{ ...cur, shipConfirmedBy: 'hoc' }] }]); assert.equal(r.body.results[0].ok, false);          // cannot change
  r = await hoc.sync([{ collection: 'fieldDeployments', upsert: [{ ...cur, receptionConfirmedBy: 'hoc', receptionConfirmedAt: 'x', deployConfirmedBy: 'hoc', deployConfirmedAt: 'x' }] }]); assert.equal(r.body.results[0].ok, true);
  cur = { ...cur, receptionConfirmedBy: 'hoc', receptionConfirmedAt: 'x', deployConfirmedBy: 'hoc', deployConfirmedAt: 'x' };
  const ad = await as('admin1', 'Password@123!');
  r = await ad.sync([{ collection: 'fieldDeployments', upsert: [{ ...cur, quantity: '9' }] }]); assert.match(r.body.results[0].error, /locked/i);   // fully confirmed => locked, even for Admin
  r = await ad.sync([{ collection: 'fieldDeployments', delete: ['fd-1'] }]); assert.equal(r.body.results[0].ok, false);
});

test('approval flow for retailer applications', async () => {
  const hoc = await as('hoc', 'Hoc@2026');
  const app1 = { id: 'ra-t1', name: 'Test Shop', zone: 'Freetown', validationStatus: 'Pending', submittedBy: 'hoc' };
  assert.equal((await hoc.sync([{ collection: 'retailers', upsert: [app1] }])).body.results[0].ok, true);
  assert.equal((await hoc.sync([{ collection: 'retailers', upsert: [{ ...app1, validationStatus: 'Validated' }] }])).body.results[0].ok, false);
  assert.equal((await hoc.sync([{ collection: 'retailers', upsert: [{ ...app1, id: 'ra-t2', validationStatus: 'Validated' }] }])).body.results[0].ok, false);
  const it = await as('itsupervisor', 'ITSup@2026');
  assert.equal((await it.sync([{ collection: 'retailers', upsert: [{ ...app1, validationStatus: 'Validated', sim: '+232 77000111' }] }])).body.results[0].ok, true);
  assert.equal((await hoc.sync([{ collection: 'retailers', upsert: [{ ...app1, sim: '+232 77000222' }] }])).body.results[0].ok, false);
});

test('HOC only receives retailer applications from their zones', async () => {
  const it = await as('itsupervisor', 'ITSup@2026');
  await it.sync([{ collection: 'retailers', upsert: [{ id: 'ra-z1', name: 'Far', zone: 'Southern 09', validationStatus: 'Validated' }] }]);
  const hoc = await as('hoc', 'Hoc@2026');
  const rows = (await hoc.req('GET', '/bootstrap')).body.collections.retailers;
  assert.ok(!rows.some(r => r.id === 'ra-z1'));
});

test('user management: validation, temp-password flow, own password change', async () => {
  const ad = await as('admin1', 'Password@123!');
  assert.equal((await ad.req('POST', '/users', { fullName: 'X', username: 'viewer', password: 'Temp12345', role: 'Viewer' })).status, 400);
  assert.equal((await ad.req('POST', '/users', { fullName: 'X', username: 'newbie', password: 'short', role: 'Viewer' })).status, 400);
  assert.equal((await ad.req('POST', '/users', { fullName: 'X', username: 'zoneless', password: 'Temp12345', role: 'HOC' })).status, 400);
  const mk = await ad.req('POST', '/users', { fullName: 'New Person', username: 'Newbie', password: 'Temp12345', role: 'IT Supervisor' });
  assert.equal(mk.status, 201); assert.equal(mk.body.user.mustChangePassword, true);
  const n = await as('newbie', 'Temp12345');
  assert.equal((await n.req('GET', '/bootstrap')).status, 403);                  // blocked until password changed
  assert.equal((await n.req('POST', '/auth/change-password', { currentPassword: 'wrong', newPassword: 'Another123' })).status, 400);
  assert.equal((await n.req('POST', '/auth/change-password', { currentPassword: 'Temp12345', newPassword: 'Another123' })).status, 200);
  assert.equal((await n.req('GET', '/bootstrap')).status, 200);
  assert.equal((await new Client().login('newbie', 'Temp12345')).status, 401);
  // non-admin cannot manage users
  assert.equal((await n.req('GET', '/users')).status, 403);
  // cannot demote/suspend self or last admin
  const me = (await ad.req('GET', '/users')).body.users.find(u => u.username === 'admin1');
  assert.equal((await ad.req('PATCH', `/users/${me.id}`, { role: 'Viewer' })).status, 400);
  // suspended user is signed out and refused
  const nid = mk.body.user.id; await ad.req('PATCH', `/users/${nid}`, { status: 'Suspended' });
  assert.equal((await n.req('GET', '/bootstrap')).status, 401);
  assert.equal((await new Client().login('newbie', 'Another123')).status, 403);
});

test('photos: base64 uploads become authenticated file URLs; bad types refused', async () => {
  const it = await as('itsupervisor', 'ITSup@2026');
  const png = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg==';
  let r = await it.sync([{ collection: 'faulty', upsert: [{ id: 'f-1', pos: 'POS-9001', imei: '356938035649001', photo: png }] }]);
  assert.equal(r.body.results[0].ok, true);
  const row = (await it.req('GET', '/bootstrap')).body.collections.faulty.find(x => x.id === 'f-1');
  assert.match(row.photo, /^\/api\/files\/[a-f0-9]{32}$/);
  const f = await fetch(base.replace('/api', '') + row.photo, { headers: { Cookie: it.cookie } });
  assert.equal(f.status, 200); assert.equal(f.headers.get('content-type'), 'image/png');
  assert.equal((await fetch(base.replace('/api', '') + row.photo)).status, 401);
  r = await it.sync([{ collection: 'faulty', upsert: [{ id: 'f-2', photo: 'data:text/html;base64,PHNjcmlwdD4=' }] }]);
  assert.equal(r.body.results[0].ok, false);
});

test('SIM register: IT/Admin upload, valid + unique SIMs, others read-only', async () => {
  const it = await as('itsupervisor', 'ITSup@2026');
  const rows = [1, 2, 3].map(n => ({ id: 'sim-' + n, sim: '+232 7700000' + n, batch: 'file.csv', uploadedBy: 'itsupervisor' }));
  let r = await it.sync([{ collection: 'simRegister', upsert: rows }]);
  assert.ok(r.body.results.every(x => x.ok), JSON.stringify(r.body.results));
  r = await it.sync([{ collection: 'simRegister', upsert: [{ id: 'sim-9', sim: '+232 77000001' }, { id: 'sim-8', sim: '12345' }] }]);
  assert.match(r.body.results[0].error, /already in the SIM register/); assert.match(r.body.results[1].error, /\+232/);
  const v = await as('viewer', 'Viewer@2026');
  assert.equal((await v.sync([{ collection: 'simRegister', upsert: [{ id: 'sim-7', sim: '+232 77000007' }] }])).body.results[0].ok, false);
  assert.equal((await v.req('GET', '/bootstrap')).body.collections.simRegister.length, 3);
  assert.equal((await it.sync([{ collection: 'simRegister', delete: ['sim-1'] }])).body.results[0].ok, false);
  assert.equal((await (await as('admin1', 'Password@123!')).sync([{ collection: 'simRegister', delete: ['sim-1'] }])).body.results[0].ok, true);
});

test('settings (stock) permissions and validation', async () => {
  const lg = await as('logistics', 'Logistics@2026');
  assert.equal((await lg.sync([], { settings: { stockBalance: 12 } })).body.results[0].ok, true);
  assert.equal((await lg.sync([], { settings: { stockBalance: 'abc' } })).body.results[0].ok, false);
  const v = await as('viewer', 'Viewer@2026');
  assert.equal((await v.sync([], { settings: { stockBalance: 99 } })).body.results[0].ok, false);
  assert.equal((await v.req('GET', '/bootstrap')).body.settings.stockBalance, 12);
});

test('data persists across restarts (rows are in SQLite)', () => {
  const n = db.prepare('SELECT COUNT(*) c FROM deployments').get().c; assert.ok(n >= 1);
});

test('full backup is Admin-only and excludes password hashes', async () => {
  const ad = await as('admin1', 'Password@123!');
  const r = await ad.req('GET', '/admin/backup');
  assert.equal(r.status, 200); assert.equal(JSON.stringify(r.body).includes('$2'), false);
  assert.equal((await (await as('supervisor', 'Supervisor@2026')).req('GET', '/admin/backup')).status, 403);
});

test('Super Admin is invisible to a plain Admin but sees everyone', async () => {
  const a = await as('admin1', 'Password@123!'), s = await as('fgbetu', 'SuperAdmin@2026');
  const la = (await a.req('GET', '/users')).body.users.map(u => u.username), ls = (await s.req('GET', '/users')).body.users.map(u => u.username);
  assert.ok(!la.includes('fgbetu'), 'plain Admin must not list the Super Admin');
  assert.ok(ls.includes('fgbetu') && ls.includes('admin1'), 'Super Admin sees all');
  const id = db.prepare("SELECT id FROM users WHERE username='fgbetu'").get().id;
  assert.equal((await a.req('PATCH', '/users/' + id, { fullName: 'X' })).status, 404);
  assert.equal((await a.req('POST', '/users/' + id + '/reset-password', { password: 'Hacked@12345' })).status, 404);
  assert.equal((await s.req('PATCH', '/users/' + id, { fullName: 'Frederick T. Gbetu' })).status, 200);
  const ba = (await a.req('GET', '/bootstrap')).body;
  assert.ok(!ba.users.some(u => u.username === 'fgbetu') && !ba.directory.some(u => u.username === 'fgbetu') && !ba.auditLog.some(r => r.user === 'fgbetu'));
  const bs = (await s.req('GET', '/bootstrap')).body;
  assert.ok(bs.users.some(u => u.username === 'fgbetu') && bs.auditLog.some(r => r.user === 'fgbetu'));
});

test('Two Super Admins can see and reset each other; plain Admin sees neither', async () => {
  const a = await as('admin1', 'Password@123!'), f = await as('fgbetu', 'SuperAdmin@2026'), m = await as('mtborbor', 'SuperAdmin2@2026');
  const la = (await a.req('GET', '/users')).body.users.map(u => u.username);
  assert.ok(!la.includes('fgbetu') && !la.includes('mtborbor'));
  const lf = (await f.req('GET', '/users')).body.users.map(u => u.username);
  assert.ok(lf.includes('mtborbor') && lf.includes('fgbetu'));
  const mid = db.prepare("SELECT id FROM users WHERE username='mtborbor'").get().id;
  assert.equal((await a.req('POST', '/users/' + mid + '/reset-password', { password: 'Hacked@12345' })).status, 404);
  assert.equal((await f.req('POST', '/users/' + mid + '/reset-password', { password: 'Fresh#Pass2026' })).status, 200);
  assert.equal((await new Client().login('mtborbor', 'Fresh#Pass2026')).status, 200);
});

test('Installable app files are served (manifest, service worker, icons)', async () => {
  const root = base.replace(/\/api$/, '');
  const m = await fetch(root + '/manifest.webmanifest'); assert.equal(m.status, 200);
  const j = await m.json(); assert.equal(j.display, 'standalone'); assert.ok(j.icons.some(i => i.sizes === '512x512'));
  assert.match(m.headers.get('content-type') || '', /json/);
  const sw = await fetch(root + '/sw.js'); assert.equal(sw.status, 200); assert.match(sw.headers.get('content-type') || '', /javascript/);
  for (const p of ['icon-192.png', 'icon-512.png', 'icon-maskable-512.png', 'apple-touch-icon.png']) assert.equal((await fetch(root + '/icons/' + p)).status, 200, p);
});
