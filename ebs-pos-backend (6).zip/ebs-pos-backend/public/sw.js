// Minimal service worker so the app can be installed.
// It NEVER caches API calls or user data: only the static app shell, and only to show a friendly offline page.
const SHELL = 'ebs-shell-v1';
self.addEventListener('install', e => { e.waitUntil(caches.open(SHELL).then(c => c.addAll(['/icons/icon-192.png'])).then(() => self.skipWaiting())); });
self.addEventListener('activate', e => { e.waitUntil(caches.keys().then(ks => Promise.all(ks.filter(k => k !== SHELL).map(k => caches.delete(k)))).then(() => self.clients.claim())); });
self.addEventListener('fetch', e => {
  const r = e.request, u = new URL(r.url);
  if (r.method !== 'GET' || u.origin !== location.origin || u.pathname.startsWith('/api/')) return; // network only
  if (r.mode === 'navigate') {
    e.respondWith(fetch(r).catch(() => new Response(
      '<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Offline</title>' +
      '<body style="font-family:system-ui;display:grid;place-items:center;min-height:100vh;margin:0;background:#17111C;color:#fff;text-align:center">' +
      '<div><h1 style="margin:0 0 8px">You are offline</h1><p>Elephant Bet POS needs a connection. Reconnect and reopen the app.</p></div>',
      { headers: { 'Content-Type': 'text/html; charset=utf-8' } })));
  }
});
