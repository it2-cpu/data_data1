# Elephant Bet SL — POS Management: Backend & Database

A Node.js + Express server with a SQLite database. It serves the same screens you already have
(`public/index.html`) and stores **all** data on the server: users, retailer applications, deployments,
maintenance, retrievals, replacements, faulty machines, shipments & field deployments, logistics & stock
(stock deliveries, spare-part receipts, balances), shipment messages, custom fields, photos and the audit log.

The screens and fields are unchanged. If you open the HTML file without the server (double-click), it still
runs as the old **demo** with sample data and nothing saved.

---
## 1. Quick start (your own computer, 3 minutes)
```bash
cd ebs-pos-backend
npm install                    # needs Node 22 or newer
cp .env.example .env          # then edit .env: set COOKIE_SECURE=0 for local testing over http
npm start                     # first run prints the Admin temporary password ONCE
```
Open **http://localhost:3000** and log in as `admin1` with the printed password. You are asked to choose a new one.
For a demo with the 7 sample accounts, set `SEED_DEMO_USERS=1` in `.env` **before the first start** (never in production).

Run the tests: `npm test` (18 tests: API rules + a browser-level end-to-end test).

---
## 2. Put it live (Ubuntu server, ~30 minutes)
You need: a small Linux server (1 vCPU / 1–2 GB RAM is plenty), a domain name (e.g. `pos.elephantbet.sl`).

1. **Install Node 22 or newer** (required): `curl -fsSL https://deb.nodesource.com/setup_22.x | sudo -E bash - && sudo apt install -y nodejs nginx`
2. **Copy the folder** to `/opt/ebs-pos`, then `cd /opt/ebs-pos && npm ci --omit=dev   (the included .npmrc skips build scripts; the database driver ships ready-made)`
3. **Configure**: `cp .env.example .env` and set `NODE_ENV=production`, `COOKIE_SECURE=1`, `ADMIN_INITIAL_PASSWORD=<a long one-time password>`, `SEED_DEMO_USERS=0`.
4. **Run it as a service** — create `/etc/systemd/system/ebs-pos.service`:
   ```
   [Unit]
   Description=EBS POS
   After=network.target
   [Service]
   WorkingDirectory=/opt/ebs-pos
   ExecStart=/usr/bin/node src/server.js
   Restart=always
   User=www-data
   [Install]
   WantedBy=multi-user.target
   ```
   `sudo chown -R www-data /opt/ebs-pos/data && sudo systemctl enable --now ebs-pos`
5. **HTTPS (required)** — nginx in front, free certificate from Let's Encrypt:
   ```
   server { server_name pos.elephantbet.sl; client_max_body_size 25m;
            location / { proxy_pass http://127.0.0.1:3000; proxy_set_header X-Forwarded-For $remote_addr; proxy_set_header X-Forwarded-Proto $scheme; } }
   ```
   `sudo apt install certbot python3-certbot-nginx && sudo certbot --nginx -d pos.elephantbet.sl`
6. **Backups (do this on day one)** — daily cron: `0 2 * * * cd /opt/ebs-pos && node scripts/backup.js /var/backups/ebs`, and copy that folder off the server (another machine / cloud storage).
   To restore: stop the service, replace `data/ebs.sqlite` (and `data/uploads`) with the backup, start the service.
7. **Firewall**: allow only ports 80, 443 and SSH.

### If the Admin is locked out or forgets the password
`node scripts/reset-admin.js admin1 "NewTemp#2026"` on the server (user must change it at next login).

---
## 3. What the server enforces (so it cannot be bypassed from the browser)
| Area | Rule |
|---|---|
| Passwords | bcrypt-hashed, never sent to the browser; minimum 8 characters; temporary passwords must be changed at first login |
| Sessions | random token in an `HttpOnly`, `SameSite=Strict` (and `Secure`) cookie; **15 minutes of inactivity** logs out; CSRF token on every change |
| Lockout | 5 wrong passwords locks the account **on the server**; Admin unlocks it (User Management → reset password) |
| Roles | every read/write/delete is checked against the user's role (table below); suspended users are signed out immediately |
| Zones | HOC / Commercial only receive retailer applications from their own zones, and can only submit new ones |
| Data rules | Machine IMEI = exactly 15 digits; SIM = `+232` + 8 digits; required fields; approval order Pending → Supervisor Approved → Validated |
| Shipments | Date of Shipment: Logistic/Admin only · Reception: HOC/Commercial/Admin · Confirmations only by the right role, under your own username, cannot be removed; fully confirmed records are **locked for everyone** and cannot be deleted |
| Audit log | written by the server for every login, failure, lockout, add, edit, delete and password change; users cannot edit or erase it |
| Photos / PDFs | stored as files (PNG/JPG/WEBP/GIF/PDF, max 5 MB) and served only to logged-in users |
| Messages | shipment notices are only delivered to the roles they were addressed to |

**Who can write what**
| Records | Admin | IT Supervisor | Supervisor | Logistic | HOC / Commercial | Viewer |
|---|---|---|---|---|---|---|
| Users | ✔ | – | – | – | – | – |
| Retailer applications | ✔ | ✔ | approve only | – | submit | – |
| Deployments, maintenance, retrievals, faulty, replacements | ✔ (delete: Admin) | ✔ | – | – | – | – |
| Shipments / field deployment | ✔ | ✔ | confirm shipment | create + dates | reception/deployment | – |
| Logistics, stock deliveries, spare-part receipts, stock balances | ✔ | ✔ | approve | ✔ | – | – |
| Audit log, full backup download | ✔ | – | – | – | – | – |
(Everyone with a login can **read** the operational screens, as in the current system.)

---
## 4. How the front end talks to the server
* On load it checks `/api/health`. If the server answers, it uses it; otherwise it runs as the demo.
* After login it downloads the data for the user's role, then **saves every change automatically** (about half a second after you click Save) with `POST /api/sync`.
  If the server refuses a change (e.g. wrong role, bad IMEI, locked record) the screen rolls back and shows the reason.
* Every 20 seconds it quietly picks up changes made by other people; it never overwrites something you have not saved yet.
* **Production page**: `node scripts/build-frontend.js frontend-demo.html` rebuilds `public/index.html` with all demo accounts, passwords and sample records removed from the page source (already done for you).

### API summary (all under `/api`)
`POST auth/login` · `POST auth/logout` · `GET auth/me` · `POST auth/change-password` · `GET bootstrap` · `POST sync` · `GET collections/:name` ·
`GET|POST users`, `PATCH users/:id`, `POST users/:id/reset-password`, `POST users/:id/unlock` (Admin) · `GET audit` (Admin) · `GET admin/backup` (Admin, JSON) · `GET files/:id`

### Database tables
`users`, `sessions`, `audit_log`, `retailer_applications`, `deployments`, `maintenance`, `retrievals`, `faulty_machines`, `replacements`,
`field_deployments`, `logistics`, `stock_deliveries`, `spare_part_receipts`, `messages`, `custom_fields`, `settings`, `files`.
Each record table has indexed `pos`, `imei`, `serial`, `zone`, `status`, `rec_date` columns plus a JSON `data` column holding the screen's fields, so adding a field in the UI needs no database change.
You can inspect it with any SQLite viewer (e.g. DB Browser for SQLite): `data/ebs.sqlite`.

---
## 5. Known limits (be aware before go-live)
* **One server, one SQLite file** — comfortable for dozens of simultaneous users and hundreds of thousands of records. Move to PostgreSQL later if you outgrow it.
* **Two people editing the same record at the same moment**: the last save wins (the other person's screen refreshes within 20 s).
* **No email password reset or two-factor login yet** — an Admin resets passwords. These are the next recommended additions.
* The "restore from backup file" button in Settings pushes that file's records to the server as normal edits (subject to the same role rules); to restore the *whole* database use the file copy described in section 2.6.
* Run a trial with real users on the live server for 1–2 weeks before retiring the old process.

## Super Admin

`SUPER_ADMINS` (default `fgbetu,mtborbor`) lists Admin accounts that are hidden from plain Admins: they do not appear in the user list, bootstrap, backups or audit log, and cannot be edited, suspended or password-reset by another Admin. A Super Admin sees everything.

## Install as an app (Admin, Logistics, HOC, Commercial)

These roles see an **Install app** button (sidebar, and in the top bar on phones). It uses the browser's native install prompt where available and shows step-by-step instructions on iPhone/iPad (Safari: Share, then Add to Home Screen), Android (Chrome menu, Install app) and computers (address-bar install icon). The button disappears once the app is installed.

Requirements: the system must be opened over **HTTPS** (browsers only allow installing secure sites). Files: `public/manifest.webmanifest`, `public/sw.js` (never caches API data) and `public/icons/*`. To use a sharper logo, replace the PNGs in `public/icons/` (192x192, 512x512, and a 512x512 maskable with ~20% padding).

## Language

The top bar (top right corner, on every page) has an English / Português / Français selector, replacing the former Messages icon. The choice is remembered in the browser. It translates every page: menus, headings, field names, form labels, table columns, buttons, placeholders and messages. Records already saved (audit-log entries, messages, names) stay in the language they were written in. Strings live in the `PT_DICT` and `FR_DICT` objects in the front-end file.

## Profile menu

Top right, after the language selector, a profile chip (initials and first name) opens a menu with **My account** (name, username, email, role, status, last login; Admins can change their password there), **About** (app information) and **Log out** (returns to the login screen).

## Watermark

Every form and application window carries a faint diagonal company logo and "ELEPHANT BET SL" watermark, and so do the printable / PDF versions of forms and reports.

## Retailer address picture and GPS

The Retailer's Registration Form has a "Retailer Address Picture (Home)" photo field right after Address. Choosing or taking the photo captures the device GPS position (the browser asks for location permission; use HTTPS). "Update GPS" re-captures it. The coordinates appear in the application view with an Open map link, on the printed form under the picture, and in the Excel/CSV export as "Retailer Address GPS".

## SIM Numbers

The SIM register has its own page. Open it with the **SIM Numbers** button at the top of the **Deployment** page, next to the "Elephant Bet SL / Deployment" path; **Back to Deployment** returns. Available to Admin, IT Supervisor and Viewer; only Admin and IT Supervisor can upload. Supervisor, Logistic, HOC and Commercial do not have the Deployment page and so not this button.

## Search & Filters

Search & Filters has its own page. Open it with the **Search & Filters** button at the top of the **Machine History** page, next to the "Elephant Bet SL / Machine History" path; **Back to Machine History** returns.

## Add Record shortcut

Under **Deployment** in the sidebar, **Add Record** opens the Deployment page with the new-record form already open. It is shown only to roles that can add deployment records (Admin and IT Supervisor).

## Dispatch Record (Deployment → Dispatch Record)

Hand-over chain for machines, each step stamped with date/time and the person's name:
IT Supervisor prepares a dispatch (type, quantity, zone, optional POS/IMEI list) → Logistics confirms received from IT → Logistics sends to zone → HOC (of that zone) confirms received → HOC chooses the Kiosk and Date of Deployment.
Status: Prepared → At Logistics → Sent to Zone → Received by HOC → Deployed. HOC/Commercial only see their own zones. Each row shows an IT → Logistics → Zone → HOC → Deployed progress tracker (hover a stage for its time and name). In the demo the records are kept in the browser (localStorage, shared by all logins on the same browser; not yet a backend collection); the existing Field Deployment flow is unchanged.

Permissions: IT Supervisor/Admin create dispatches; Logistic confirms "received from IT" and "send to zone"; HOC (own zones)/Commercial can confirm only after Logistics has sent to the zone (received, then kiosk + deployment date). Admin can do every step.

Dispatch Record also has a **View** (eye) icon per row — full details, stage timeline with times/names — and a **Report a problem** button that records the message (time, name, role) on the dispatch and notifies the other roles (IT Supervisor, Logistic, HOC, Commercial, Admin) through the shipment-message inbox.

**Dispatch ↔ Search & Filters link:** in *New Dispatch* the "Machines" box takes one machine per line (POS, IMEI, Serial, SIM separated by commas). Searching a POS / IMEI / Serial / SIM number on *Machine History → Search & Filters* now also finds those dispatches: existing machines get Zone, Kiosk and Dispatch ID columns filled in, and machines that are only in a dispatch (not yet deployed) appear as "In Dispatch — <stage>" (or "Deployed (Dispatch)" once the HOC has chosen the kiosk). Status filter has a new "In Dispatch" option.

**Dispatch → Add Record autofill:** in *Deployment → Add Record*, typing a POS number that is listed in a Dispatch Record fills IMEI, Serial, SIM, Zone, Kiosk and Date of Deployment (kiosk/date once the HOC has confirmed) and shows "Linked to Dispatch Record DP-…". The saved deployment keeps the dispatch ID in `dispatchId`.

**Dispatch form fields:** *New Dispatch* now takes Machine type, Zone, Kiosk and one row per machine with POS Number, IMEI (15 digits), Serial Number and SIM Number (+232 + 8 digits); "Add machine" adds rows, quantity is counted automatically, duplicates are rejected. The kiosk chosen by IT is pre-selected when the HOC confirms deployment (the HOC can change it). Search & Filters and the Add Record autofill use these fields.

*New Dispatch* opens with every field blank (Machine type included) and has a **Clear all** button that resets the whole form.

**Prepare Dispatch ↔ Deployment link:** typing a POS number that exists in Deployment Records (or the machine register) fills IMEI, Serial and SIM Number automatically and locks them; if the deployment has a zone/kiosk and the form's zone is empty, those fill too. A POS number not found shows a warning but can still be dispatched (new stock not yet deployed); saved machines keep a `linked` flag.

**Per-machine Zone and Kiosk:** each machine row in *Prepare Dispatch* has its own Zone and Kiosk (they default to the dispatch's Zone/Kiosk and are filled from the deployment record when it has them). They are saved on each machine (`zone`, `kiosk`), shown in the View table, and used by the Add Record autofill.

**Prepare Dispatch layout:** the dispatch-level Zone and Kiosk at the top were removed — Zone and Kiosk are now required per machine row, and the Machines section is wider with larger fields. The dispatch's zone list/HOC zone filtering use the machines' zones (a dispatch may span several zones; an HOC sees a dispatch if any machine is in their zone).

**Machine Type on retailer applications:** the IT Supervisor's final confirmation now asks for the Machine Type (V2, V2s or Urovo i9200) together with POS, IMEI, Serial and SIM; it is required, saved as `machineType` on the application, shown in the application form/print, and copied to the auto-created deployment record. Dispatch Record's Machine type list has the same three options.

**Per-machine details in Prepare Dispatch:** each machine row now carries POS Number, IMEI, Serial, SIM Number, **Machine type** (V2 / V2s / Urovo i9200), **Zone** and **Kiosk** (all required; kiosk list follows the row's zone). The dispatch's machine type shows as e.g. "V2 + V2s" when mixed. Saved machines store `type`, `zone`, `kiosk`.

The Prepare Dispatch form and the dispatch View window carry a letterhead: logo, "Elephant Bet SL", "44 Siaka Steven St".

**Print dispatch:** each Dispatch Record row has a printer icon (and the View window a *Print* button) that opens a printable page — letterhead, dispatch details, machines table (POS, IMEI, Serial, SIM, type, zone, kiosk), confirmation stages with time/name, problems reported, signature lines for IT / Logistics / HOC, and the logo watermark. Use the browser's Print → Save as PDF.

Removed from the front-end: the *Shipment*, *Reception*, *Field Deployment* and *Add Record* menu items, the Field Deployment page and the Add Record shortcut. Deployment now contains only *Dispatch Record*. Stored field-deployment data and the backend `fieldDeployments` collection are left in place (still used by reports/dashboard counts).

Dashboard: the stock table has a "STOCK UPDATES" title on top, above the "Spare Part" and "Stock Updates" column headings.

Dashboard stock table: the right-hand column heading is now "Park Machines" (the "STOCK UPDATES" title stays on top; "Park Machines" has no Portuguese/French translation yet and shows in English).

Log out (profile menu) now asks "Do you confirm logout?" with *No* / *Yes, log out* before ending the session.

**Goodies (Logistic Department → Goodies):** stock log for promotional items (T-Shirt, Cap, Umbrella, Pen, Bag, Calendar, Poster, Other). Logistic/Admin add records — *Received* (from whom) or *Issued* (zone, kiosk, to whom); an issue cannot exceed the balance in store. Balances per item show as cards on top; every record carries date/time and the person who recorded it. Other roles with the Logistic Department menu (Supervisor, IT Supervisor, Viewer) see it read-only. In the demo the records are stored in the browser (not yet a backend collection).

**Goodies in Confirm deployment:** the HOC's *Confirm deployment* window has an optional Goodies section (item + quantity, add as many rows as needed; "Other" takes a custom name). They are saved on the dispatch (`goodies`), shown in the View window and on the printout. They do not change the Goodies stock page.

**HOC confirms machine by machine:** when a dispatch is *Sent to Zone*, the HOC's action is *Confirm machines* (shows n / N confirmed). The window lists the machines in the order IT entered them (POS, IMEI, Serial, SIM, type, kiosk); the HOC confirms them one at a time — each stamped with time and name — and only the next unconfirmed machine can be confirmed. HOC/Commercial can confirm only machines in their own zones. When every machine is confirmed the dispatch moves to *Received by HOC* and the HOC can then *Confirm deployment*. The View window and printout show each machine's HOC receipt time/name. (Dispatches created before this change, without a machine list, keep the single "Confirm received" button.)

**Goodies question at deployment:** *Confirm deployment* now asks the HOC "Did you issue out goodies?" (Yes/No, required). *Yes* shows the item/quantity rows (at least one needed); *No* takes an optional reason. The answer is saved on the dispatch (`goodiesIssued`, `goodies`, `goodiesNote`) and appears in the View window and the printout.

When the HOC answers *Yes* to the goodies question, a required "Which type of goodies?" list appears (type + quantity per row: T-Shirt, Cap, Umbrella, Pen, Bag, Calendar, Poster, Other).

Goodies at deployment are now a checklist: the HOC ticks every type issued out (T-Shirt, Cap, Umbrella, Pen, Bag, Calendar, Poster, Other + name) and enters a quantity for each.

### Goodies → POS
When the HOC confirms a deployment and answers "Yes" to issuing goodies, each ticked goodies type also lists the dispatch's POS numbers (all preselected). At least one POS must stay ticked per type. Saved as `goodies:[{item,qty,pos[]}]`; shown in View as `qty × item (POS: …)` and in Print as an "Issued to POS" column.

### Retrieved Machines workflow
HOC/Commercial record a retrieved machine ("Retrieve machine"); Logistics confirms it and sends it to IT; IT confirms receipt. Fields on each retrieval record: `retrievedAt/By`, `logRecvAt/By`, `sentToItAt/By`, `itRecvAt/By` (ISO timestamps). Logistic, HOC and Commercial now see "Retrieved Machines" in the sidebar; HOC/Commercial are limited to their zones. Demo rows persist in localStorage `ebs_retrieval`.

Retrieved Machines: IT Supervisor is review-only (no add/edit). Logistics, IT and HOC can send a "Report a problem" message on a retrieval record; it is stored in `issues[{at,by,role,msg}]` and notified to the other roles.

Retrieved Machines messages are now a thread: any role can reply from the record view; replies are stored in `issues[]` with `reply:true` and notified to the other roles.

Retrieved Machines rejection: at "Sent to IT", IT can Reject with a reason (`rejectedAt/By`, message stored in `issues[]` with `reject:true`). Status becomes "Rejected by IT"; the HOC edits and resubmits, which clears `rejectedAt`, `logRecvAt` and `sentToItAt` so Logistics confirms again.

Replacement Machines now uses the same workflow as Retrieved Machines (HOC logs → Logistics confirms/sends to IT → IT confirms or rejects → HOC edits and resubmits, with timestamps and message thread). Rows persist in localStorage `ebs_replacement`; fields are unchanged (`dateReplaced`, `pos`, `imei`, `serial`, `zone`, `kiosk`, `notes`) plus workflow timestamps.

Dashboard now shows a SIM NUMBERS block (Total SIMs / Assigned to a POS / Available) computed from the SIM register and deployments; hidden for Logistic, HOC and Commercial.

Maintenance Records > Faulty now shows summary tiles: Total Faulty plus counts per machine type (V2, V2s, Urovo i9200), with machine type looked up from the deployment by IMEI/serial/POS.

Maintenance records have a new "Type of Machine" field (V2 / V2s / Urovo i9200, `machineType`); the Faulty tab tiles count by it, falling back to the deployment record.

Faulty tab: Type of Fault now includes Screen, Printer Head, Battery, Screen and Battery, Screen and Printer Head, Printer Head and Battery, Vandalized, Out of Order (and Network); the tab shows a Total tile for each.

Maintenance records: new `timeIn` / `timeOut` (HH:MM). On save, `duration` (minutes) and `rating` are stored: under 5 min Excellent, 5-10 Very Good, 11-15 Good, over 15 "Need to improve speed". Time out before time in is rejected; Completed requires both times. When both times are present they replace the old fault-type stopwatch toast.

Maintenance Records rows: History and Delete removed; every row has View; Edit remains only while Status is "In Progress" (so Time Out can be entered to complete).

Logistic dashboard now also shows SIM NUMBERS (now visible to Logistic), DISPATCH STATUS (counts per stage) and GOODIES STOCK (in-store balance per item).

HOC / Commercial now have a Dashboard (landing page after login), limited to their zones: NEEDS YOUR ATTENTION (dispatches to receive/deploy, rejected records to fix), DISPATCH STATUS, RETRIEVED MACHINES and REPLACEMENT MACHINES by stage, and RETAILER APPLICATIONS by status.
